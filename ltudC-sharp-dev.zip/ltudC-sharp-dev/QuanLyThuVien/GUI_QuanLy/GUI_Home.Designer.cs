﻿namespace GUI_QuanLy
{
    partial class GUI_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GUI_Home));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lbTittle = new System.Windows.Forms.Label();
            this.ptB_AnhNhanVien = new System.Windows.Forms.PictureBox();
            this.userName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelQLSach = new System.Windows.Forms.Panel();
            this.tbcQuanLiSach = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnYeuCauTL = new System.Windows.Forms.Button();
            this.btnXemTheoLoai = new System.Windows.Forms.Button();
            this.cbxLoaiTaiLieu = new System.Windows.Forms.ComboBox();
            this.btnChinhSuaTL = new System.Windows.Forms.Button();
            this.btnHuyTL = new System.Windows.Forms.Button();
            this.btnLuuTL = new System.Windows.Forms.Button();
            this.btnXemAllTaiLieu = new System.Windows.Forms.Button();
            this.btnLapPhieuMuonTL = new System.Windows.Forms.Button();
            this.btnXoaTL = new System.Windows.Forms.Button();
            this.btnXemChiTietTL = new System.Windows.Forms.Button();
            this.dgvSearchTaiLieu = new System.Windows.Forms.DataGridView();
            this.btnSearchTaiLieu = new System.Windows.Forms.Button();
            this.lblTenTaiLieu = new System.Windows.Forms.Label();
            this.lblMaTaiLieu = new System.Windows.Forms.Label();
            this.rdTimTLNangCao = new System.Windows.Forms.RadioButton();
            this.rdTimTLCoBan = new System.Windows.Forms.RadioButton();
            this.txtSearchTaiLieu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ckbTLDB = new System.Windows.Forms.CheckBox();
            this.btnThemTaiLieu = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMaTL = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSoLuongTL = new System.Windows.Forms.TextBox();
            this.txtLoaiTL = new System.Windows.Forms.TextBox();
            this.txtTenTL = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbTenTaiLieuYeuCauMoi = new System.Windows.Forms.Label();
            this.txtYeuCauTaiLieuMoi = new System.Windows.Forms.TextBox();
            this.btnYeuCauTaiLieuMoi = new System.Windows.Forms.Button();
            this.btnXoaYeuCauTaiLieuMoi = new System.Windows.Forms.Button();
            this.dgvYeuCauTaiLieu = new System.Windows.Forms.DataGridView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnQuanTriAdmin = new System.Windows.Forms.Button();
            this.btnBaoCaoThongKe = new System.Windows.Forms.Button();
            this.btnDocGia = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnQuanLyPhieu = new System.Windows.Forms.Button();
            this.btnPanelSach = new System.Windows.Forms.Button();
            this.panelReport = new System.Windows.Forms.Panel();
            this.cryReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btnSaveReport = new System.Windows.Forms.Button();
            this.btnReport_TongSoDocGia = new System.Windows.Forms.Button();
            this.btnReport_SoSachMuonNhieuNhat = new System.Windows.Forms.Button();
            this.btnReport_TongSoSach = new System.Windows.Forms.Button();
            this.pnThongKe = new System.Windows.Forms.Panel();
            this.tbcQuanLiPhieu = new System.Windows.Forms.TabControl();
            this.tabPhieuMuon = new System.Windows.Forms.TabPage();
            this.tbcPhieuMuon = new System.Windows.Forms.TabControl();
            this.tabTimKiemPhieuMuon = new System.Windows.Forms.TabPage();
            this.txtCapNhatCTPM = new System.Windows.Forms.TextBox();
            this.btnChinhSua_CTPM = new System.Windows.Forms.Button();
            this.btnHuy_PhieuMuon = new System.Windows.Forms.Button();
            this.btnLuuCTPM = new System.Windows.Forms.Button();
            this.btnXemTatcaPhieuMuon = new System.Windows.Forms.Button();
            this.btnXoaPhieuMuon = new System.Windows.Forms.Button();
            this.btnXemChiTiet_PhieuMuon = new System.Windows.Forms.Button();
            this.dgvPhieuMuon = new System.Windows.Forms.DataGridView();
            this.btnTimKiemPhieuMuon = new System.Windows.Forms.Button();
            this.rdMaPhieuMuon = new System.Windows.Forms.RadioButton();
            this.rdMaDG_PhieuMuon = new System.Windows.Forms.RadioButton();
            this.txtSearchPM = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.tabThemPhieuMuon = new System.Windows.Forms.TabPage();
            this.lbMaDocGiaPhieuMuon = new System.Windows.Forms.Label();
            this.lbMaDocGia = new System.Windows.Forms.Label();
            this.lbMaTLPhieuMuon = new System.Windows.Forms.Label();
            this.lbMaTaiLieuPhieuMuon = new System.Windows.Forms.Label();
            this.lbListSachMuonHide = new System.Windows.Forms.ListBox();
            this.btnXoaMTLTrongList = new System.Windows.Forms.Button();
            this.btnAddMTLVaoList = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.cbxMaTLPM = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cbxMaDGPM = new System.Windows.Forms.ComboBox();
            this.lbListSachMuon = new System.Windows.Forms.ListBox();
            this.btnThem_PhieuMuon = new System.Windows.Forms.Button();
            this.tabPhieuTra = new System.Windows.Forms.TabPage();
            this.tbcPhieuTra = new System.Windows.Forms.TabControl();
            this.tabPage_TimkiemPhieuTra = new System.Windows.Forms.TabPage();
            this.rdMaPhieuMuon_PhieuTraTK = new System.Windows.Forms.RadioButton();
            this.btnChinhSua_PhieuTra = new System.Windows.Forms.Button();
            this.btnHuy_PhieuTra = new System.Windows.Forms.Button();
            this.btnLuuPhieuTra = new System.Windows.Forms.Button();
            this.btnXemTatCaPhieuTra = new System.Windows.Forms.Button();
            this.btnXoaPhieuTra = new System.Windows.Forms.Button();
            this.btnXemChiTietPhieuTra = new System.Windows.Forms.Button();
            this.dgvPhieuTra = new System.Windows.Forms.DataGridView();
            this.btnTimKiemPhieuTra = new System.Windows.Forms.Button();
            this.rdMaPhieuTra = new System.Windows.Forms.RadioButton();
            this.rdMaDG_PhieuTra = new System.Windows.Forms.RadioButton();
            this.txtSearchPT = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.tabpage_ThemPhieuTra = new System.Windows.Forms.TabPage();
            this.lbDanhSachSachTraHide = new System.Windows.Forms.ListBox();
            this.btnXoaSachTra = new System.Windows.Forms.Button();
            this.btnAddSachTra = new System.Windows.Forms.Button();
            this.cbxSachPT = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbDanhSachSachTra = new System.Windows.Forms.ListBox();
            this.cbxMaPMCuaPT = new System.Windows.Forms.ComboBox();
            this.btnThemPhieuTra = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.btnXoaPT = new System.Windows.Forms.Button();
            this.btnXemChiTietPT = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnTimKiemPT = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.tabPhieuPhat = new System.Windows.Forms.TabPage();
            this.rdMPP_PP = new System.Windows.Forms.RadioButton();
            this.cbxMaPMcuaPP = new System.Windows.Forms.ComboBox();
            this.btn_LapPhieuPhat = new System.Windows.Forms.Button();
            this.lbMaPM_PP = new System.Windows.Forms.Label();
            this.btnXemTatCaPhieuPhat = new System.Windows.Forms.Button();
            this.btnXoaPP = new System.Windows.Forms.Button();
            this.dgvPhieuPhat = new System.Windows.Forms.DataGridView();
            this.btnSearchPP = new System.Windows.Forms.Button();
            this.rdMaPM_PP = new System.Windows.Forms.RadioButton();
            this.rdMDG_PP = new System.Windows.Forms.RadioButton();
            this.txtSearchMaPP = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.tabPhieuNhacNho = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMaPNN = new System.Windows.Forms.TextBox();
            this.btnSearchPNN = new System.Windows.Forms.Button();
            this.btnChinhSuaPNN = new System.Windows.Forms.Button();
            this.cbxmaDocGiaNN = new System.Windows.Forms.ComboBox();
            this.btnXemTatCaPhieuNhacNho = new System.Windows.Forms.Button();
            this.btnXoaPhieuNN = new System.Windows.Forms.Button();
            this.dgvPhieuNhacNho = new System.Windows.Forms.DataGridView();
            this.btnThemPhieuNhacNho = new System.Windows.Forms.Button();
            this.panelQuanTriAdmin = new System.Windows.Forms.Panel();
            this.tbcQuanTriAdmin = new System.Windows.Forms.TabControl();
            this.tbcAdmin_DocGia = new System.Windows.Forms.TabPage();
            this.dgvLoaiDocGia = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtADTLDB = new System.Windows.Forms.TextBox();
            this.txtADTDG = new System.Windows.Forms.TextBox();
            this.btnADTLDG = new System.Windows.Forms.Button();
            this.btnADCNLDG = new System.Windows.Forms.Button();
            this.txtADPTN = new System.Windows.Forms.TextBox();
            this.txtADSSM = new System.Windows.Forms.TextBox();
            this.txtADSoNM = new System.Windows.Forms.TextBox();
            this.txtADMaLoai = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tbcAdmin_NhanVien = new System.Windows.Forms.TabPage();
            this.txtMatKhauNVCapNhat = new System.Windows.Forms.TextBox();
            this.txtHoTenNVCapNhat = new System.Windows.Forms.TextBox();
            this.txtTenDangNhapNVCapNhat = new System.Windows.Forms.TextBox();
            this.txtCaTrucNVCapNhat = new System.Windows.Forms.TextBox();
            this.txtSearchPhieuMuon = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.rdAdminCapNhat = new System.Windows.Forms.RadioButton();
            this.rdThuThuCapNhat = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.btnCapNhatNhanVien = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.tbcDocGia = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.txtCTMSSV_DG = new System.Windows.Forms.TextBox();
            this.lbCTMSSV_DG = new System.Windows.Forms.Label();
            this.txtCTMSCB_DG = new System.Windows.Forms.TextBox();
            this.lbCTMSCB_DG = new System.Windows.Forms.Label();
            this.dtkCTNgaySinhDG = new System.Windows.Forms.DateTimePicker();
            this.rdCTKhach_DG = new System.Windows.Forms.RadioButton();
            this.rdCTCB_DG = new System.Windows.Forms.RadioButton();
            this.rdCTSV_DG = new System.Windows.Forms.RadioButton();
            this.lbCTLoaiDG = new System.Windows.Forms.Label();
            this.txtCTPhoneDG = new System.Windows.Forms.TextBox();
            this.lbCTPhoneDG = new System.Windows.Forms.Label();
            this.txtCTCMNDDG = new System.Windows.Forms.TextBox();
            this.txtCTMaDG = new System.Windows.Forms.TextBox();
            this.txtCTEmailDG = new System.Windows.Forms.TextBox();
            this.txtCTDiaChiDG = new System.Windows.Forms.TextBox();
            this.txtCTTenDG = new System.Windows.Forms.TextBox();
            this.lbCTCMNDDG = new System.Windows.Forms.Label();
            this.lbCTEmailDG = new System.Windows.Forms.Label();
            this.lbCTDiaChiDG = new System.Windows.Forms.Label();
            this.lbCTNgaySinhDG = new System.Windows.Forms.Label();
            this.lbCTMaDG = new System.Windows.Forms.Label();
            this.lbCTTenDG = new System.Windows.Forms.Label();
            this.cbxDinhDanh = new System.Windows.Forms.ComboBox();
            this.btnChinhSua = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXemAllDocGia = new System.Windows.Forms.Button();
            this.btnLapPhieuCanhCao = new System.Windows.Forms.Button();
            this.btnLapPhieuTra = new System.Windows.Forms.Button();
            this.btnLapPhieMuon = new System.Windows.Forms.Button();
            this.btnXoaDocGia = new System.Windows.Forms.Button();
            this.btnXemChiTiet = new System.Windows.Forms.Button();
            this.dgvDGSearch = new System.Windows.Forms.DataGridView();
            this.btnSearchDocGia = new System.Windows.Forms.Button();
            this.lblHoTenSearch = new System.Windows.Forms.Label();
            this.lblDinhDanhSearch = new System.Windows.Forms.Label();
            this.lblMaDGSearch = new System.Windows.Forms.Label();
            this.rdHoTenSearch = new System.Windows.Forms.RadioButton();
            this.rdMaDinhDanhSearch = new System.Windows.Forms.RadioButton();
            this.rdMaDGSearch = new System.Windows.Forms.RadioButton();
            this.txtSearchDG = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tabThemdg = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnDangKyDocGia = new System.Windows.Forms.Button();
            this.dtpk_ngaysinhDocGia = new System.Windows.Forms.DateTimePicker();
            this.txtMaDG = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblMSCBDangKy = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblMSSVDangKy = new System.Windows.Forms.Label();
            this.rdKhac = new System.Windows.Forms.RadioButton();
            this.rdCanBo = new System.Windows.Forms.RadioButton();
            this.rdSinhVien = new System.Windows.Forms.RadioButton();
            this.txtCMNDDG = new System.Windows.Forms.TextBox();
            this.txtMSCBDG = new System.Windows.Forms.TextBox();
            this.txtMSSVDG = new System.Windows.Forms.TextBox();
            this.txtEmailDG = new System.Windows.Forms.TextBox();
            this.txtSDTDG = new System.Windows.Forms.TextBox();
            this.txtDiaChiDG = new System.Windows.Forms.TextBox();
            this.txtTenDG = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbUserName = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panelDocGia = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList3 = new System.Windows.Forms.ImageList(this.components);
            this.btnLogout = new System.Windows.Forms.Button();
            this.imageList4 = new System.Windows.Forms.ImageList(this.components);
            this.imageList5 = new System.Windows.Forms.ImageList(this.components);
            this.imageList6 = new System.Windows.Forms.ImageList(this.components);
            this.cbxCTTLDB = new System.Windows.Forms.CheckBox();
            this.lbCTSoLuongTL = new System.Windows.Forms.Label();
            this.txtCTMaTaiLieu = new System.Windows.Forms.TextBox();
            this.lbCTMaTL = new System.Windows.Forms.Label();
            this.txtCTSoLuongTL = new System.Windows.Forms.TextBox();
            this.txtCTTenTaiLieu = new System.Windows.Forms.TextBox();
            this.lbCTLoaiTaiLieu = new System.Windows.Forms.Label();
            this.lbCTTenTaiLieu = new System.Windows.Forms.Label();
            this.cbbCTLoaiTL = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptB_AnhNhanVien)).BeginInit();
            this.panelQLSach.SuspendLayout();
            this.tbcQuanLiSach.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchTaiLieu)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYeuCauTaiLieu)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.panelReport.SuspendLayout();
            this.pnThongKe.SuspendLayout();
            this.tbcQuanLiPhieu.SuspendLayout();
            this.tabPhieuMuon.SuspendLayout();
            this.tbcPhieuMuon.SuspendLayout();
            this.tabTimKiemPhieuMuon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuMuon)).BeginInit();
            this.tabThemPhieuMuon.SuspendLayout();
            this.tabPhieuTra.SuspendLayout();
            this.tbcPhieuTra.SuspendLayout();
            this.tabPage_TimkiemPhieuTra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuTra)).BeginInit();
            this.tabpage_ThemPhieuTra.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPhieuPhat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuPhat)).BeginInit();
            this.tabPhieuNhacNho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNhacNho)).BeginInit();
            this.panelQuanTriAdmin.SuspendLayout();
            this.tbcQuanTriAdmin.SuspendLayout();
            this.tbcAdmin_DocGia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoaiDocGia)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tbcAdmin_NhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.tbcDocGia.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDGSearch)).BeginInit();
            this.tabThemdg.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panelDocGia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.ForeColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(1050, -1);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(78, 32);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(43, 33);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.btnMinimized_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(39, -2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(43, 35);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnClosed_Click);
            // 
            // lbTittle
            // 
            this.lbTittle.AutoSize = true;
            this.lbTittle.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbTittle.Font = new System.Drawing.Font("Constantia", 18F, System.Drawing.FontStyle.Bold);
            this.lbTittle.ForeColor = System.Drawing.Color.Lime;
            this.lbTittle.Location = new System.Drawing.Point(316, 25);
            this.lbTittle.Name = "lbTittle";
            this.lbTittle.Size = new System.Drawing.Size(385, 29);
            this.lbTittle.TabIndex = 1;
            this.lbTittle.Text = "PHẦM MỀM QUẢN LÝ THƯ VIỆN";
            this.lbTittle.Click += new System.EventHandler(this.lbTittle_Click);
            this.lbTittle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.lbTittle.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.lbTittle.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // ptB_AnhNhanVien
            // 
            this.ptB_AnhNhanVien.Image = ((System.Drawing.Image)(resources.GetObject("ptB_AnhNhanVien.Image")));
            this.ptB_AnhNhanVien.Location = new System.Drawing.Point(794, 21);
            this.ptB_AnhNhanVien.MaximumSize = new System.Drawing.Size(75, 60);
            this.ptB_AnhNhanVien.MinimumSize = new System.Drawing.Size(75, 60);
            this.ptB_AnhNhanVien.Name = "ptB_AnhNhanVien";
            this.ptB_AnhNhanVien.Size = new System.Drawing.Size(75, 60);
            this.ptB_AnhNhanVien.TabIndex = 2;
            this.ptB_AnhNhanVien.TabStop = false;
            this.ptB_AnhNhanVien.Click += new System.EventHandler(this.ptB_AnhNhanVien_Click);
            // 
            // userName
            // 
            this.userName.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.userName.Location = new System.Drawing.Point(880, 27);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(203, 31);
            this.userName.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(885, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Thủ Thư";
            // 
            // panelQLSach
            // 
            this.panelQLSach.Controls.Add(this.tbcQuanLiSach);
            this.panelQLSach.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.panelQLSach.Location = new System.Drawing.Point(123, 12);
            this.panelQLSach.Name = "panelQLSach";
            this.panelQLSach.Size = new System.Drawing.Size(911, 470);
            this.panelQLSach.TabIndex = 11;
            // 
            // tbcQuanLiSach
            // 
            this.tbcQuanLiSach.Controls.Add(this.tabPage1);
            this.tbcQuanLiSach.Controls.Add(this.tabPage8);
            this.tbcQuanLiSach.Controls.Add(this.tabPage2);
            this.tbcQuanLiSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbcQuanLiSach.ItemSize = new System.Drawing.Size(110, 28);
            this.tbcQuanLiSach.Location = new System.Drawing.Point(0, 0);
            this.tbcQuanLiSach.Name = "tbcQuanLiSach";
            this.tbcQuanLiSach.Padding = new System.Drawing.Point(12, 3);
            this.tbcQuanLiSach.SelectedIndex = 0;
            this.tbcQuanLiSach.Size = new System.Drawing.Size(911, 446);
            this.tbcQuanLiSach.TabIndex = 0;
            this.tbcQuanLiSach.SelectedIndexChanged += new System.EventHandler(this.tbcQuanLiSach_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.cbbCTLoaiTL);
            this.tabPage1.Controls.Add(this.cbxCTTLDB);
            this.tabPage1.Controls.Add(this.lbCTSoLuongTL);
            this.tabPage1.Controls.Add(this.txtCTMaTaiLieu);
            this.tabPage1.Controls.Add(this.lbCTMaTL);
            this.tabPage1.Controls.Add(this.txtCTSoLuongTL);
            this.tabPage1.Controls.Add(this.txtCTTenTaiLieu);
            this.tabPage1.Controls.Add(this.lbCTLoaiTaiLieu);
            this.tabPage1.Controls.Add(this.lbCTTenTaiLieu);
            this.tabPage1.Controls.Add(this.btnYeuCauTL);
            this.tabPage1.Controls.Add(this.btnXemTheoLoai);
            this.tabPage1.Controls.Add(this.cbxLoaiTaiLieu);
            this.tabPage1.Controls.Add(this.btnChinhSuaTL);
            this.tabPage1.Controls.Add(this.btnHuyTL);
            this.tabPage1.Controls.Add(this.btnLuuTL);
            this.tabPage1.Controls.Add(this.btnXemAllTaiLieu);
            this.tabPage1.Controls.Add(this.btnLapPhieuMuonTL);
            this.tabPage1.Controls.Add(this.btnXoaTL);
            this.tabPage1.Controls.Add(this.btnXemChiTietTL);
            this.tabPage1.Controls.Add(this.dgvSearchTaiLieu);
            this.tabPage1.Controls.Add(this.btnSearchTaiLieu);
            this.tabPage1.Controls.Add(this.lblTenTaiLieu);
            this.tabPage1.Controls.Add(this.lblMaTaiLieu);
            this.tabPage1.Controls.Add(this.rdTimTLNangCao);
            this.tabPage1.Controls.Add(this.rdTimTLCoBan);
            this.tabPage1.Controls.Add(this.txtSearchTaiLieu);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(903, 410);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "Tìm KiếmTài Liệu";
            // 
            // btnYeuCauTL
            // 
            this.btnYeuCauTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnYeuCauTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYeuCauTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYeuCauTL.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnYeuCauTL.Location = new System.Drawing.Point(684, 348);
            this.btnYeuCauTL.Name = "btnYeuCauTL";
            this.btnYeuCauTL.Size = new System.Drawing.Size(176, 41);
            this.btnYeuCauTL.TabIndex = 24;
            this.btnYeuCauTL.Text = "Yêu Cầu Tài Liệu Mới";
            this.btnYeuCauTL.UseVisualStyleBackColor = false;
            this.btnYeuCauTL.Click += new System.EventHandler(this.btnYeuCauTL_Click);
            // 
            // btnXemTheoLoai
            // 
            this.btnXemTheoLoai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(40)))), ((int)(((byte)(0)))));
            this.btnXemTheoLoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemTheoLoai.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemTheoLoai.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemTheoLoai.Location = new System.Drawing.Point(617, 67);
            this.btnXemTheoLoai.Name = "btnXemTheoLoai";
            this.btnXemTheoLoai.Size = new System.Drawing.Size(123, 33);
            this.btnXemTheoLoai.TabIndex = 23;
            this.btnXemTheoLoai.Text = "Xem Theo Loại";
            this.btnXemTheoLoai.UseVisualStyleBackColor = false;
            this.btnXemTheoLoai.Click += new System.EventHandler(this.btnXemTheoLoai_Click);
            // 
            // cbxLoaiTaiLieu
            // 
            this.cbxLoaiTaiLieu.Font = new System.Drawing.Font("Constantia", 10F);
            this.cbxLoaiTaiLieu.FormattingEnabled = true;
            this.cbxLoaiTaiLieu.Location = new System.Drawing.Point(762, 71);
            this.cbxLoaiTaiLieu.Name = "cbxLoaiTaiLieu";
            this.cbxLoaiTaiLieu.Size = new System.Drawing.Size(121, 23);
            this.cbxLoaiTaiLieu.TabIndex = 22;
            this.cbxLoaiTaiLieu.Text = "SÁCH";
            // 
            // btnChinhSuaTL
            // 
            this.btnChinhSuaTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(139)))), ((int)(((byte)(25)))));
            this.btnChinhSuaTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChinhSuaTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChinhSuaTL.ForeColor = System.Drawing.Color.White;
            this.btnChinhSuaTL.Location = new System.Drawing.Point(155, 347);
            this.btnChinhSuaTL.Name = "btnChinhSuaTL";
            this.btnChinhSuaTL.Size = new System.Drawing.Size(117, 43);
            this.btnChinhSuaTL.TabIndex = 21;
            this.btnChinhSuaTL.Text = "Chỉnh Sửa";
            this.btnChinhSuaTL.UseVisualStyleBackColor = false;
            this.btnChinhSuaTL.Click += new System.EventHandler(this.btnChinhSuaTL_Click);
            // 
            // btnHuyTL
            // 
            this.btnHuyTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(139)))), ((int)(((byte)(25)))));
            this.btnHuyTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuyTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuyTL.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHuyTL.Location = new System.Drawing.Point(617, 346);
            this.btnHuyTL.Name = "btnHuyTL";
            this.btnHuyTL.Size = new System.Drawing.Size(142, 44);
            this.btnHuyTL.TabIndex = 20;
            this.btnHuyTL.Text = "Hủy";
            this.btnHuyTL.UseVisualStyleBackColor = false;
            this.btnHuyTL.Click += new System.EventHandler(this.btnHuyTL_Click);
            // 
            // btnLuuTL
            // 
            this.btnLuuTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(139)))), ((int)(((byte)(25)))));
            this.btnLuuTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuuTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuTL.ForeColor = System.Drawing.Color.White;
            this.btnLuuTL.Location = new System.Drawing.Point(400, 347);
            this.btnLuuTL.Name = "btnLuuTL";
            this.btnLuuTL.Size = new System.Drawing.Size(117, 43);
            this.btnLuuTL.TabIndex = 19;
            this.btnLuuTL.Text = "Lưu";
            this.btnLuuTL.UseVisualStyleBackColor = false;
            this.btnLuuTL.Click += new System.EventHandler(this.btnLuuTL_Click);
            // 
            // btnXemAllTaiLieu
            // 
            this.btnXemAllTaiLieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemAllTaiLieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemAllTaiLieu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemAllTaiLieu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemAllTaiLieu.Location = new System.Drawing.Point(617, 20);
            this.btnXemAllTaiLieu.Name = "btnXemAllTaiLieu";
            this.btnXemAllTaiLieu.Size = new System.Drawing.Size(123, 33);
            this.btnXemAllTaiLieu.TabIndex = 18;
            this.btnXemAllTaiLieu.Text = "Xem Tất Cả";
            this.btnXemAllTaiLieu.UseVisualStyleBackColor = false;
            this.btnXemAllTaiLieu.Click += new System.EventHandler(this.btnXemAllTaiLieu_Click);
            // 
            // btnLapPhieuMuonTL
            // 
            this.btnLapPhieuMuonTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnLapPhieuMuonTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLapPhieuMuonTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieuMuonTL.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLapPhieuMuonTL.Location = new System.Drawing.Point(468, 348);
            this.btnLapPhieuMuonTL.Name = "btnLapPhieuMuonTL";
            this.btnLapPhieuMuonTL.Size = new System.Drawing.Size(142, 41);
            this.btnLapPhieuMuonTL.TabIndex = 15;
            this.btnLapPhieuMuonTL.Text = "Lập Phiếu Mượn";
            this.btnLapPhieuMuonTL.UseVisualStyleBackColor = false;
            this.btnLapPhieuMuonTL.Click += new System.EventHandler(this.btnLapPhieuMuonTL_Click);
            // 
            // btnXoaTL
            // 
            this.btnXoaTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnXoaTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTL.ForeColor = System.Drawing.Color.White;
            this.btnXoaTL.Location = new System.Drawing.Point(244, 348);
            this.btnXoaTL.Name = "btnXoaTL";
            this.btnXoaTL.Size = new System.Drawing.Size(117, 41);
            this.btnXoaTL.TabIndex = 14;
            this.btnXoaTL.Text = "Xóa";
            this.btnXoaTL.UseVisualStyleBackColor = false;
            this.btnXoaTL.Click += new System.EventHandler(this.btnXoaTL_Click);
            // 
            // btnXemChiTietTL
            // 
            this.btnXemChiTietTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnXemChiTietTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemChiTietTL.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemChiTietTL.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemChiTietTL.Location = new System.Drawing.Point(32, 347);
            this.btnXemChiTietTL.Name = "btnXemChiTietTL";
            this.btnXemChiTietTL.Size = new System.Drawing.Size(117, 41);
            this.btnXemChiTietTL.TabIndex = 13;
            this.btnXemChiTietTL.Text = "Xem Chi Tiết";
            this.btnXemChiTietTL.UseVisualStyleBackColor = false;
            this.btnXemChiTietTL.Click += new System.EventHandler(this.btnXemChiTietTL_Click);
            // 
            // dgvSearchTaiLieu
            // 
            this.dgvSearchTaiLieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSearchTaiLieu.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvSearchTaiLieu.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvSearchTaiLieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvSearchTaiLieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearchTaiLieu.GridColor = System.Drawing.SystemColors.Control;
            this.dgvSearchTaiLieu.Location = new System.Drawing.Point(10, 111);
            this.dgvSearchTaiLieu.Name = "dgvSearchTaiLieu";
            this.dgvSearchTaiLieu.Size = new System.Drawing.Size(890, 220);
            this.dgvSearchTaiLieu.TabIndex = 9;
            // 
            // btnSearchTaiLieu
            // 
            this.btnSearchTaiLieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSearchTaiLieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchTaiLieu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchTaiLieu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearchTaiLieu.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchTaiLieu.Image")));
            this.btnSearchTaiLieu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearchTaiLieu.Location = new System.Drawing.Point(424, 67);
            this.btnSearchTaiLieu.Name = "btnSearchTaiLieu";
            this.btnSearchTaiLieu.Size = new System.Drawing.Size(123, 33);
            this.btnSearchTaiLieu.TabIndex = 8;
            this.btnSearchTaiLieu.Text = "Tìm Kiếm";
            this.btnSearchTaiLieu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearchTaiLieu.UseVisualStyleBackColor = false;
            this.btnSearchTaiLieu.Click += new System.EventHandler(this.btnSearchTaiLieu_Click);
            // 
            // lblTenTaiLieu
            // 
            this.lblTenTaiLieu.AutoSize = true;
            this.lblTenTaiLieu.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenTaiLieu.Location = new System.Drawing.Point(275, 20);
            this.lblTenTaiLieu.Name = "lblTenTaiLieu";
            this.lblTenTaiLieu.Size = new System.Drawing.Size(86, 20);
            this.lblTenTaiLieu.TabIndex = 6;
            this.lblTenTaiLieu.Text = "Tên Tài Liệu";
            // 
            // lblMaTaiLieu
            // 
            this.lblMaTaiLieu.AutoSize = true;
            this.lblMaTaiLieu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaTaiLieu.Location = new System.Drawing.Point(273, 19);
            this.lblMaTaiLieu.Name = "lblMaTaiLieu";
            this.lblMaTaiLieu.Size = new System.Drawing.Size(103, 21);
            this.lblMaTaiLieu.TabIndex = 5;
            this.lblMaTaiLieu.Text = "Mã Tài Liệu :";
            // 
            // rdTimTLNangCao
            // 
            this.rdTimTLNangCao.AutoSize = true;
            this.rdTimTLNangCao.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdTimTLNangCao.Location = new System.Drawing.Point(140, 61);
            this.rdTimTLNangCao.Name = "rdTimTLNangCao";
            this.rdTimTLNangCao.Size = new System.Drawing.Size(128, 24);
            this.rdTimTLNangCao.TabIndex = 3;
            this.rdTimTLNangCao.TabStop = true;
            this.rdTimTLNangCao.Text = "Tìm Nâng Cao";
            this.rdTimTLNangCao.UseVisualStyleBackColor = true;
            this.rdTimTLNangCao.CheckedChanged += new System.EventHandler(this.rdTimTLNangCao_CheckedChanged);
            // 
            // rdTimTLCoBan
            // 
            this.rdTimTLCoBan.AutoSize = true;
            this.rdTimTLCoBan.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdTimTLCoBan.Location = new System.Drawing.Point(140, 16);
            this.rdTimTLCoBan.Name = "rdTimTLCoBan";
            this.rdTimTLCoBan.Size = new System.Drawing.Size(103, 24);
            this.rdTimTLCoBan.TabIndex = 2;
            this.rdTimTLCoBan.TabStop = true;
            this.rdTimTLCoBan.Text = "Tìm Cơ Bản";
            this.rdTimTLCoBan.UseVisualStyleBackColor = true;
            this.rdTimTLCoBan.CheckedChanged += new System.EventHandler(this.rdTimTLCoBan_CheckedChanged);
            // 
            // txtSearchTaiLieu
            // 
            this.txtSearchTaiLieu.Location = new System.Drawing.Point(378, 20);
            this.txtSearchTaiLieu.Name = "txtSearchTaiLieu";
            this.txtSearchTaiLieu.Size = new System.Drawing.Size(227, 23);
            this.txtSearchTaiLieu.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tìm Kiếm Theo :";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage8.Controls.Add(this.groupBox4);
            this.tabPage8.Location = new System.Drawing.Point(4, 32);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(903, 410);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Thêm Tài Liệu";
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox4.Controls.Add(this.ckbTLDB);
            this.groupBox4.Controls.Add(this.btnThemTaiLieu);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txtMaTL);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txtSoLuongTL);
            this.groupBox4.Controls.Add(this.txtLoaiTL);
            this.groupBox4.Controls.Add(this.txtTenTL);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Location = new System.Drawing.Point(28, 29);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox4.Size = new System.Drawing.Size(847, 355);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // ckbTLDB
            // 
            this.ckbTLDB.AutoSize = true;
            this.ckbTLDB.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbTLDB.Location = new System.Drawing.Point(145, 143);
            this.ckbTLDB.Name = "ckbTLDB";
            this.ckbTLDB.Size = new System.Drawing.Size(149, 21);
            this.ckbTLDB.TabIndex = 76;
            this.ckbTLDB.Text = "Là Tài Liệu Đặc Biệt";
            this.ckbTLDB.UseVisualStyleBackColor = true;
            // 
            // btnThemTaiLieu
            // 
            this.btnThemTaiLieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(99)))), ((int)(((byte)(25)))));
            this.btnThemTaiLieu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnThemTaiLieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemTaiLieu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTaiLieu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThemTaiLieu.Location = new System.Drawing.Point(308, 197);
            this.btnThemTaiLieu.Name = "btnThemTaiLieu";
            this.btnThemTaiLieu.Size = new System.Drawing.Size(157, 38);
            this.btnThemTaiLieu.TabIndex = 75;
            this.btnThemTaiLieu.Text = "Thêm";
            this.btnThemTaiLieu.UseVisualStyleBackColor = false;
            this.btnThemTaiLieu.Click += new System.EventHandler(this.btnThemTaiLieu_Click);
            // 
            // label4
            // 
            this.label4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(399, 64);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(2);
            this.label4.Size = new System.Drawing.Size(130, 54);
            this.label4.TabIndex = 74;
            this.label4.Text = "Số Lượng :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.UseCompatibleTextRendering = true;
            // 
            // txtMaTL
            // 
            this.txtMaTL.Location = new System.Drawing.Point(145, 28);
            this.txtMaTL.Name = "txtMaTL";
            this.txtMaTL.Size = new System.Drawing.Size(211, 23);
            this.txtMaTL.TabIndex = 73;
            // 
            // label5
            // 
            this.label5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(5, 9);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(2);
            this.label5.Size = new System.Drawing.Size(130, 54);
            this.label5.TabIndex = 72;
            this.label5.Text = "Mã Tài Liệu :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.UseCompatibleTextRendering = true;
            // 
            // txtSoLuongTL
            // 
            this.txtSoLuongTL.Location = new System.Drawing.Point(536, 83);
            this.txtSoLuongTL.Name = "txtSoLuongTL";
            this.txtSoLuongTL.Size = new System.Drawing.Size(211, 23);
            this.txtSoLuongTL.TabIndex = 60;
            // 
            // txtLoaiTL
            // 
            this.txtLoaiTL.Location = new System.Drawing.Point(537, 29);
            this.txtLoaiTL.Name = "txtLoaiTL";
            this.txtLoaiTL.Size = new System.Drawing.Size(211, 23);
            this.txtLoaiTL.TabIndex = 59;
            // 
            // txtTenTL
            // 
            this.txtTenTL.Location = new System.Drawing.Point(145, 83);
            this.txtTenTL.Name = "txtTenTL";
            this.txtTenTL.Size = new System.Drawing.Size(211, 23);
            this.txtTenTL.TabIndex = 57;
            // 
            // label9
            // 
            this.label9.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label9.Location = new System.Drawing.Point(393, 13);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(2);
            this.label9.Size = new System.Drawing.Size(130, 54);
            this.label9.TabIndex = 42;
            this.label9.Text = "Loại Tài Liệu :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.UseCompatibleTextRendering = true;
            // 
            // label14
            // 
            this.label14.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label14.Location = new System.Drawing.Point(8, 64);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(2);
            this.label14.Size = new System.Drawing.Size(127, 54);
            this.label14.TabIndex = 40;
            this.label14.Text = "Tên Tài Liệu :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label14.UseCompatibleTextRendering = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.lbTenTaiLieuYeuCauMoi);
            this.tabPage2.Controls.Add(this.txtYeuCauTaiLieuMoi);
            this.tabPage2.Controls.Add(this.btnYeuCauTaiLieuMoi);
            this.tabPage2.Controls.Add(this.btnXoaYeuCauTaiLieuMoi);
            this.tabPage2.Controls.Add(this.dgvYeuCauTaiLieu);
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(903, 410);
            this.tabPage2.TabIndex = 8;
            this.tabPage2.Text = "Tài Liệu Yêu Cầu";
            // 
            // lbTenTaiLieuYeuCauMoi
            // 
            this.lbTenTaiLieuYeuCauMoi.AutoSize = true;
            this.lbTenTaiLieuYeuCauMoi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenTaiLieuYeuCauMoi.Location = new System.Drawing.Point(12, 361);
            this.lbTenTaiLieuYeuCauMoi.Name = "lbTenTaiLieuYeuCauMoi";
            this.lbTenTaiLieuYeuCauMoi.Size = new System.Drawing.Size(83, 20);
            this.lbTenTaiLieuYeuCauMoi.TabIndex = 41;
            this.lbTenTaiLieuYeuCauMoi.Text = "Nhập Tên :";
            this.lbTenTaiLieuYeuCauMoi.Visible = false;
            // 
            // txtYeuCauTaiLieuMoi
            // 
            this.txtYeuCauTaiLieuMoi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYeuCauTaiLieuMoi.Location = new System.Drawing.Point(114, 355);
            this.txtYeuCauTaiLieuMoi.MaxLength = 35;
            this.txtYeuCauTaiLieuMoi.Name = "txtYeuCauTaiLieuMoi";
            this.txtYeuCauTaiLieuMoi.Size = new System.Drawing.Size(193, 26);
            this.txtYeuCauTaiLieuMoi.TabIndex = 40;
            this.txtYeuCauTaiLieuMoi.Visible = false;
            // 
            // btnYeuCauTaiLieuMoi
            // 
            this.btnYeuCauTaiLieuMoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(99)))), ((int)(((byte)(25)))));
            this.btnYeuCauTaiLieuMoi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnYeuCauTaiLieuMoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYeuCauTaiLieuMoi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYeuCauTaiLieuMoi.ForeColor = System.Drawing.Color.White;
            this.btnYeuCauTaiLieuMoi.Location = new System.Drawing.Point(342, 345);
            this.btnYeuCauTaiLieuMoi.Name = "btnYeuCauTaiLieuMoi";
            this.btnYeuCauTaiLieuMoi.Size = new System.Drawing.Size(170, 41);
            this.btnYeuCauTaiLieuMoi.TabIndex = 39;
            this.btnYeuCauTaiLieuMoi.Text = "Yêu Cầu Tài Liệu Mới ";
            this.btnYeuCauTaiLieuMoi.UseVisualStyleBackColor = false;
            this.btnYeuCauTaiLieuMoi.Click += new System.EventHandler(this.btnYeuCauTaiLieuMoi_Click);
            // 
            // btnXoaYeuCauTaiLieuMoi
            // 
            this.btnXoaYeuCauTaiLieuMoi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(40)))), ((int)(((byte)(0)))));
            this.btnXoaYeuCauTaiLieuMoi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXoaYeuCauTaiLieuMoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaYeuCauTaiLieuMoi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaYeuCauTaiLieuMoi.ForeColor = System.Drawing.Color.White;
            this.btnXoaYeuCauTaiLieuMoi.Image = ((System.Drawing.Image)(resources.GetObject("btnXoaYeuCauTaiLieuMoi.Image")));
            this.btnXoaYeuCauTaiLieuMoi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXoaYeuCauTaiLieuMoi.Location = new System.Drawing.Point(594, 345);
            this.btnXoaYeuCauTaiLieuMoi.Name = "btnXoaYeuCauTaiLieuMoi";
            this.btnXoaYeuCauTaiLieuMoi.Size = new System.Drawing.Size(117, 41);
            this.btnXoaYeuCauTaiLieuMoi.TabIndex = 34;
            this.btnXoaYeuCauTaiLieuMoi.Text = "Xóa";
            this.btnXoaYeuCauTaiLieuMoi.UseVisualStyleBackColor = false;
            this.btnXoaYeuCauTaiLieuMoi.Click += new System.EventHandler(this.btnXoaYeuCauTaiLieuMoi_Click);
            // 
            // dgvYeuCauTaiLieu
            // 
            this.dgvYeuCauTaiLieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvYeuCauTaiLieu.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvYeuCauTaiLieu.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvYeuCauTaiLieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvYeuCauTaiLieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYeuCauTaiLieu.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvYeuCauTaiLieu.Location = new System.Drawing.Point(0, 0);
            this.dgvYeuCauTaiLieu.Name = "dgvYeuCauTaiLieu";
            this.dgvYeuCauTaiLieu.Size = new System.Drawing.Size(903, 325);
            this.dgvYeuCauTaiLieu.TabIndex = 32;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã Sách";
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên Sách";
            this.columnHeader2.Width = 118;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "NXB";
            this.columnHeader3.Width = 77;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tác Giả";
            this.columnHeader4.Width = 81;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Năm XB";
            this.columnHeader5.Width = 76;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Lần XB";
            this.columnHeader6.Width = 71;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Số lượng ";
            this.columnHeader7.Width = 76;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Nội dung";
            this.columnHeader8.Width = 130;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.btnQuanTriAdmin);
            this.groupBox2.Controls.Add(this.btnBaoCaoThongKe);
            this.groupBox2.Controls.Add(this.btnDocGia);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnQuanLyPhieu);
            this.groupBox2.Controls.Add(this.btnPanelSach);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 472);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // btnQuanTriAdmin
            // 
            this.btnQuanTriAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(130)))), ((int)(((byte)(100)))));
            this.btnQuanTriAdmin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuanTriAdmin.FlatAppearance.BorderSize = 0;
            this.btnQuanTriAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanTriAdmin.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanTriAdmin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnQuanTriAdmin.Image = ((System.Drawing.Image)(resources.GetObject("btnQuanTriAdmin.Image")));
            this.btnQuanTriAdmin.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnQuanTriAdmin.Location = new System.Drawing.Point(32, 353);
            this.btnQuanTriAdmin.Name = "btnQuanTriAdmin";
            this.btnQuanTriAdmin.Size = new System.Drawing.Size(145, 74);
            this.btnQuanTriAdmin.TabIndex = 17;
            this.btnQuanTriAdmin.Text = "Quản Trị Admin";
            this.btnQuanTriAdmin.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnQuanTriAdmin.UseVisualStyleBackColor = false;
            this.btnQuanTriAdmin.Visible = false;
            this.btnQuanTriAdmin.Click += new System.EventHandler(this.btnQuanTriAdmin_Click);
            // 
            // btnBaoCaoThongKe
            // 
            this.btnBaoCaoThongKe.BackColor = System.Drawing.Color.Orange;
            this.btnBaoCaoThongKe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBaoCaoThongKe.FlatAppearance.BorderSize = 0;
            this.btnBaoCaoThongKe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBaoCaoThongKe.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaoCaoThongKe.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBaoCaoThongKe.Image = ((System.Drawing.Image)(resources.GetObject("btnBaoCaoThongKe.Image")));
            this.btnBaoCaoThongKe.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBaoCaoThongKe.Location = new System.Drawing.Point(32, 279);
            this.btnBaoCaoThongKe.Name = "btnBaoCaoThongKe";
            this.btnBaoCaoThongKe.Size = new System.Drawing.Size(145, 74);
            this.btnBaoCaoThongKe.TabIndex = 16;
            this.btnBaoCaoThongKe.Text = "Thống Kê";
            this.btnBaoCaoThongKe.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBaoCaoThongKe.UseVisualStyleBackColor = false;
            this.btnBaoCaoThongKe.Click += new System.EventHandler(this.btnBaoCaoThongKe_Click);
            // 
            // btnDocGia
            // 
            this.btnDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnDocGia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDocGia.FlatAppearance.BorderSize = 0;
            this.btnDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocGia.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocGia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDocGia.Image = ((System.Drawing.Image)(resources.GetObject("btnDocGia.Image")));
            this.btnDocGia.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnDocGia.Location = new System.Drawing.Point(32, 131);
            this.btnDocGia.Name = "btnDocGia";
            this.btnDocGia.Size = new System.Drawing.Size(145, 74);
            this.btnDocGia.TabIndex = 14;
            this.btnDocGia.Text = "Độc giả";
            this.btnDocGia.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDocGia.UseVisualStyleBackColor = false;
            this.btnDocGia.Click += new System.EventHandler(this.btnDocGia_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(40, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 23);
            this.label2.TabIndex = 13;
            this.label2.Text = "Danh Mục";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnQuanLyPhieu
            // 
            this.btnQuanLyPhieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnQuanLyPhieu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuanLyPhieu.FlatAppearance.BorderSize = 0;
            this.btnQuanLyPhieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuanLyPhieu.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuanLyPhieu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnQuanLyPhieu.Image = ((System.Drawing.Image)(resources.GetObject("btnQuanLyPhieu.Image")));
            this.btnQuanLyPhieu.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnQuanLyPhieu.Location = new System.Drawing.Point(32, 205);
            this.btnQuanLyPhieu.Name = "btnQuanLyPhieu";
            this.btnQuanLyPhieu.Size = new System.Drawing.Size(145, 74);
            this.btnQuanLyPhieu.TabIndex = 11;
            this.btnQuanLyPhieu.Text = "Quản Lý Phiếu";
            this.btnQuanLyPhieu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnQuanLyPhieu.UseVisualStyleBackColor = false;
            this.btnQuanLyPhieu.Click += new System.EventHandler(this.btnThongKe_Click);
            // 
            // btnPanelSach
            // 
            this.btnPanelSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(99)))), ((int)(((byte)(25)))));
            this.btnPanelSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPanelSach.FlatAppearance.BorderSize = 0;
            this.btnPanelSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPanelSach.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPanelSach.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPanelSach.Image = ((System.Drawing.Image)(resources.GetObject("btnPanelSach.Image")));
            this.btnPanelSach.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPanelSach.Location = new System.Drawing.Point(32, 57);
            this.btnPanelSach.Name = "btnPanelSach";
            this.btnPanelSach.Size = new System.Drawing.Size(145, 74);
            this.btnPanelSach.TabIndex = 8;
            this.btnPanelSach.Text = "Quản Lý Sách";
            this.btnPanelSach.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPanelSach.UseVisualStyleBackColor = false;
            this.btnPanelSach.Click += new System.EventHandler(this.btnPanelSach_Click);
            // 
            // panelReport
            // 
            this.panelReport.Controls.Add(this.cryReportViewer);
            this.panelReport.Controls.Add(this.btnSaveReport);
            this.panelReport.Controls.Add(this.btnReport_TongSoDocGia);
            this.panelReport.Controls.Add(this.btnReport_SoSachMuonNhieuNhat);
            this.panelReport.Controls.Add(this.btnReport_TongSoSach);
            this.panelReport.Location = new System.Drawing.Point(948, 58);
            this.panelReport.Name = "panelReport";
            this.panelReport.Size = new System.Drawing.Size(911, 470);
            this.panelReport.TabIndex = 14;
            // 
            // cryReportViewer
            // 
            this.cryReportViewer.ActiveViewIndex = -1;
            this.cryReportViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cryReportViewer.Cursor = System.Windows.Forms.Cursors.Default;
            this.cryReportViewer.Location = new System.Drawing.Point(14, 55);
            this.cryReportViewer.Name = "cryReportViewer";
            this.cryReportViewer.ShowGroupTreeButton = false;
            this.cryReportViewer.Size = new System.Drawing.Size(852, 355);
            this.cryReportViewer.TabIndex = 63;
            this.cryReportViewer.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            this.cryReportViewer.Visible = false;
            // 
            // btnSaveReport
            // 
            this.btnSaveReport.BackColor = System.Drawing.Color.Orange;
            this.btnSaveReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveReport.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveReport.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveReport.Location = new System.Drawing.Point(387, 425);
            this.btnSaveReport.Name = "btnSaveReport";
            this.btnSaveReport.Size = new System.Drawing.Size(145, 38);
            this.btnSaveReport.TabIndex = 17;
            this.btnSaveReport.Text = "Lưu Thống Kê";
            this.btnSaveReport.UseVisualStyleBackColor = false;
            this.btnSaveReport.Click += new System.EventHandler(this.btnSaveReport_Click);
            // 
            // btnReport_TongSoDocGia
            // 
            this.btnReport_TongSoDocGia.BackColor = System.Drawing.Color.SeaGreen;
            this.btnReport_TongSoDocGia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReport_TongSoDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport_TongSoDocGia.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport_TongSoDocGia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport_TongSoDocGia.Location = new System.Drawing.Point(210, 5);
            this.btnReport_TongSoDocGia.Name = "btnReport_TongSoDocGia";
            this.btnReport_TongSoDocGia.Size = new System.Drawing.Size(145, 38);
            this.btnReport_TongSoDocGia.TabIndex = 62;
            this.btnReport_TongSoDocGia.Text = "Số lượng Độc Giả";
            this.btnReport_TongSoDocGia.UseVisualStyleBackColor = false;
            this.btnReport_TongSoDocGia.Click += new System.EventHandler(this.btnReport_TongSoDocGia_Click);
            // 
            // btnReport_SoSachMuonNhieuNhat
            // 
            this.btnReport_SoSachMuonNhieuNhat.BackColor = System.Drawing.Color.SeaGreen;
            this.btnReport_SoSachMuonNhieuNhat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReport_SoSachMuonNhieuNhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport_SoSachMuonNhieuNhat.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport_SoSachMuonNhieuNhat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport_SoSachMuonNhieuNhat.Location = new System.Drawing.Point(427, 5);
            this.btnReport_SoSachMuonNhieuNhat.Name = "btnReport_SoSachMuonNhieuNhat";
            this.btnReport_SoSachMuonNhieuNhat.Size = new System.Drawing.Size(190, 38);
            this.btnReport_SoSachMuonNhieuNhat.TabIndex = 61;
            this.btnReport_SoSachMuonNhieuNhat.Text = "Số Sách Mượn Nhiểu Nhất";
            this.btnReport_SoSachMuonNhieuNhat.UseVisualStyleBackColor = false;
            this.btnReport_SoSachMuonNhieuNhat.Click += new System.EventHandler(this.btnReport_SoSachMuonNhieuNhat_Click);
            // 
            // btnReport_TongSoSach
            // 
            this.btnReport_TongSoSach.BackColor = System.Drawing.Color.SeaGreen;
            this.btnReport_TongSoSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReport_TongSoSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport_TongSoSach.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport_TongSoSach.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReport_TongSoSach.Location = new System.Drawing.Point(14, 6);
            this.btnReport_TongSoSach.Name = "btnReport_TongSoSach";
            this.btnReport_TongSoSach.Size = new System.Drawing.Size(145, 38);
            this.btnReport_TongSoSach.TabIndex = 56;
            this.btnReport_TongSoSach.Text = "Tổng Số Sách ";
            this.btnReport_TongSoSach.UseVisualStyleBackColor = false;
            this.btnReport_TongSoSach.Click += new System.EventHandler(this.btnReport_TongSoSach_Click);
            // 
            // pnThongKe
            // 
            this.pnThongKe.BackColor = System.Drawing.SystemColors.Control;
            this.pnThongKe.Controls.Add(this.tbcQuanLiPhieu);
            this.pnThongKe.Location = new System.Drawing.Point(975, 38);
            this.pnThongKe.Name = "pnThongKe";
            this.pnThongKe.Size = new System.Drawing.Size(911, 470);
            this.pnThongKe.TabIndex = 15;
            // 
            // tbcQuanLiPhieu
            // 
            this.tbcQuanLiPhieu.Controls.Add(this.tabPhieuMuon);
            this.tbcQuanLiPhieu.Controls.Add(this.tabPhieuTra);
            this.tbcQuanLiPhieu.Controls.Add(this.tabPhieuPhat);
            this.tbcQuanLiPhieu.Controls.Add(this.tabPhieuNhacNho);
            this.tbcQuanLiPhieu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcQuanLiPhieu.ItemSize = new System.Drawing.Size(115, 28);
            this.tbcQuanLiPhieu.Location = new System.Drawing.Point(0, 0);
            this.tbcQuanLiPhieu.Margin = new System.Windows.Forms.Padding(0);
            this.tbcQuanLiPhieu.Name = "tbcQuanLiPhieu";
            this.tbcQuanLiPhieu.Padding = new System.Drawing.Point(0, 0);
            this.tbcQuanLiPhieu.SelectedIndex = 0;
            this.tbcQuanLiPhieu.Size = new System.Drawing.Size(911, 470);
            this.tbcQuanLiPhieu.TabIndex = 0;
            // 
            // tabPhieuMuon
            // 
            this.tabPhieuMuon.BackColor = System.Drawing.SystemColors.Control;
            this.tabPhieuMuon.Controls.Add(this.tbcPhieuMuon);
            this.tabPhieuMuon.Location = new System.Drawing.Point(4, 32);
            this.tabPhieuMuon.Name = "tabPhieuMuon";
            this.tabPhieuMuon.Size = new System.Drawing.Size(903, 434);
            this.tabPhieuMuon.TabIndex = 4;
            this.tabPhieuMuon.Text = "Phiếu Mượn";
            // 
            // tbcPhieuMuon
            // 
            this.tbcPhieuMuon.Controls.Add(this.tabTimKiemPhieuMuon);
            this.tbcPhieuMuon.Controls.Add(this.tabThemPhieuMuon);
            this.tbcPhieuMuon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcPhieuMuon.ItemSize = new System.Drawing.Size(110, 28);
            this.tbcPhieuMuon.Location = new System.Drawing.Point(0, 0);
            this.tbcPhieuMuon.Name = "tbcPhieuMuon";
            this.tbcPhieuMuon.SelectedIndex = 0;
            this.tbcPhieuMuon.Size = new System.Drawing.Size(903, 434);
            this.tbcPhieuMuon.TabIndex = 0;
            // 
            // tabTimKiemPhieuMuon
            // 
            this.tabTimKiemPhieuMuon.BackColor = System.Drawing.SystemColors.Control;
            this.tabTimKiemPhieuMuon.Controls.Add(this.txtCapNhatCTPM);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnChinhSua_CTPM);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnHuy_PhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnLuuCTPM);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnXemTatcaPhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnXoaPhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnXemChiTiet_PhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.dgvPhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.btnTimKiemPhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.rdMaPhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.rdMaDG_PhieuMuon);
            this.tabTimKiemPhieuMuon.Controls.Add(this.txtSearchPM);
            this.tabTimKiemPhieuMuon.Controls.Add(this.label47);
            this.tabTimKiemPhieuMuon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabTimKiemPhieuMuon.Location = new System.Drawing.Point(4, 32);
            this.tabTimKiemPhieuMuon.Name = "tabTimKiemPhieuMuon";
            this.tabTimKiemPhieuMuon.Padding = new System.Windows.Forms.Padding(3);
            this.tabTimKiemPhieuMuon.Size = new System.Drawing.Size(895, 398);
            this.tabTimKiemPhieuMuon.TabIndex = 1;
            this.tabTimKiemPhieuMuon.Text = "Tìm Kiếm Phiếu Mượn";
            // 
            // txtCapNhatCTPM
            // 
            this.txtCapNhatCTPM.Location = new System.Drawing.Point(19, 64);
            this.txtCapNhatCTPM.Name = "txtCapNhatCTPM";
            this.txtCapNhatCTPM.Size = new System.Drawing.Size(100, 21);
            this.txtCapNhatCTPM.TabIndex = 56;
            // 
            // btnChinhSua_CTPM
            // 
            this.btnChinhSua_CTPM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(62)))), ((int)(((byte)(129)))));
            this.btnChinhSua_CTPM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChinhSua_CTPM.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChinhSua_CTPM.ForeColor = System.Drawing.Color.White;
            this.btnChinhSua_CTPM.Location = new System.Drawing.Point(75, 339);
            this.btnChinhSua_CTPM.Name = "btnChinhSua_CTPM";
            this.btnChinhSua_CTPM.Size = new System.Drawing.Size(138, 43);
            this.btnChinhSua_CTPM.TabIndex = 55;
            this.btnChinhSua_CTPM.Text = "Chỉnh Sửa";
            this.btnChinhSua_CTPM.UseVisualStyleBackColor = false;
            this.btnChinhSua_CTPM.Click += new System.EventHandler(this.btnChinhSua_PhieuMuon_Click);
            // 
            // btnHuy_PhieuMuon
            // 
            this.btnHuy_PhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(62)))), ((int)(((byte)(129)))));
            this.btnHuy_PhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuy_PhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy_PhieuMuon.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHuy_PhieuMuon.Location = new System.Drawing.Point(689, 337);
            this.btnHuy_PhieuMuon.Name = "btnHuy_PhieuMuon";
            this.btnHuy_PhieuMuon.Size = new System.Drawing.Size(94, 44);
            this.btnHuy_PhieuMuon.TabIndex = 54;
            this.btnHuy_PhieuMuon.Text = "Hủy";
            this.btnHuy_PhieuMuon.UseVisualStyleBackColor = false;
            this.btnHuy_PhieuMuon.Click += new System.EventHandler(this.btnHuy_PhieuMuon_Click);
            // 
            // btnLuuCTPM
            // 
            this.btnLuuCTPM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(62)))), ((int)(((byte)(129)))));
            this.btnLuuCTPM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuuCTPM.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuCTPM.ForeColor = System.Drawing.Color.White;
            this.btnLuuCTPM.Location = new System.Drawing.Point(377, 338);
            this.btnLuuCTPM.Name = "btnLuuCTPM";
            this.btnLuuCTPM.Size = new System.Drawing.Size(138, 43);
            this.btnLuuCTPM.TabIndex = 53;
            this.btnLuuCTPM.Text = "Lưu";
            this.btnLuuCTPM.UseVisualStyleBackColor = false;
            this.btnLuuCTPM.Visible = false;
            this.btnLuuCTPM.Click += new System.EventHandler(this.btnLuuPhieuMuon_Click);
            // 
            // btnXemTatcaPhieuMuon
            // 
            this.btnXemTatcaPhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemTatcaPhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemTatcaPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemTatcaPhieuMuon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemTatcaPhieuMuon.Location = new System.Drawing.Point(659, 20);
            this.btnXemTatcaPhieuMuon.Name = "btnXemTatcaPhieuMuon";
            this.btnXemTatcaPhieuMuon.Size = new System.Drawing.Size(116, 33);
            this.btnXemTatcaPhieuMuon.TabIndex = 52;
            this.btnXemTatcaPhieuMuon.Text = "Xem Tất Cả";
            this.btnXemTatcaPhieuMuon.UseVisualStyleBackColor = false;
            this.btnXemTatcaPhieuMuon.Click += new System.EventHandler(this.btnXemTatcaPhieuMuon_Click);
            // 
            // btnXoaPhieuMuon
            // 
            this.btnXoaPhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXoaPhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPhieuMuon.ForeColor = System.Drawing.Color.White;
            this.btnXoaPhieuMuon.Location = new System.Drawing.Point(190, 340);
            this.btnXoaPhieuMuon.Name = "btnXoaPhieuMuon";
            this.btnXoaPhieuMuon.Size = new System.Drawing.Size(117, 41);
            this.btnXoaPhieuMuon.TabIndex = 49;
            this.btnXoaPhieuMuon.Text = "Xóa";
            this.btnXoaPhieuMuon.UseVisualStyleBackColor = false;
            this.btnXoaPhieuMuon.Click += new System.EventHandler(this.btnXoaPhieuMuon_Click);
            // 
            // btnXemChiTiet_PhieuMuon
            // 
            this.btnXemChiTiet_PhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXemChiTiet_PhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemChiTiet_PhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemChiTiet_PhieuMuon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemChiTiet_PhieuMuon.Location = new System.Drawing.Point(17, 341);
            this.btnXemChiTiet_PhieuMuon.Name = "btnXemChiTiet_PhieuMuon";
            this.btnXemChiTiet_PhieuMuon.Size = new System.Drawing.Size(117, 41);
            this.btnXemChiTiet_PhieuMuon.TabIndex = 48;
            this.btnXemChiTiet_PhieuMuon.Text = "Xem Chi Tiết";
            this.btnXemChiTiet_PhieuMuon.UseVisualStyleBackColor = false;
            this.btnXemChiTiet_PhieuMuon.Click += new System.EventHandler(this.btnXemChiTiet_PhieuMuon_Click);
            // 
            // dgvPhieuMuon
            // 
            this.dgvPhieuMuon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuMuon.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPhieuMuon.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPhieuMuon.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPhieuMuon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuMuon.Location = new System.Drawing.Point(7, 118);
            this.dgvPhieuMuon.Name = "dgvPhieuMuon";
            this.dgvPhieuMuon.Size = new System.Drawing.Size(840, 199);
            this.dgvPhieuMuon.TabIndex = 47;
            this.dgvPhieuMuon.DoubleClick += new System.EventHandler(this.dgvPhieuMuon_DoubleClick);
            // 
            // btnTimKiemPhieuMuon
            // 
            this.btnTimKiemPhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnTimKiemPhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimKiemPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemPhieuMuon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTimKiemPhieuMuon.Image = ((System.Drawing.Image)(resources.GetObject("btnTimKiemPhieuMuon.Image")));
            this.btnTimKiemPhieuMuon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimKiemPhieuMuon.Location = new System.Drawing.Point(495, 20);
            this.btnTimKiemPhieuMuon.Name = "btnTimKiemPhieuMuon";
            this.btnTimKiemPhieuMuon.Size = new System.Drawing.Size(123, 33);
            this.btnTimKiemPhieuMuon.TabIndex = 46;
            this.btnTimKiemPhieuMuon.Text = "Tìm Kiếm";
            this.btnTimKiemPhieuMuon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTimKiemPhieuMuon.UseVisualStyleBackColor = false;
            this.btnTimKiemPhieuMuon.Click += new System.EventHandler(this.btnTimKiemPhieuMuon_Click);
            // 
            // rdMaPhieuMuon
            // 
            this.rdMaPhieuMuon.AutoSize = true;
            this.rdMaPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaPhieuMuon.Location = new System.Drawing.Point(137, 46);
            this.rdMaPhieuMuon.Name = "rdMaPhieuMuon";
            this.rdMaPhieuMuon.Size = new System.Drawing.Size(133, 23);
            this.rdMaPhieuMuon.TabIndex = 43;
            this.rdMaPhieuMuon.TabStop = true;
            this.rdMaPhieuMuon.Text = "Mã Phiếu Mượn";
            this.rdMaPhieuMuon.UseVisualStyleBackColor = true;
            // 
            // rdMaDG_PhieuMuon
            // 
            this.rdMaDG_PhieuMuon.AutoSize = true;
            this.rdMaDG_PhieuMuon.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaDG_PhieuMuon.Location = new System.Drawing.Point(137, 10);
            this.rdMaDG_PhieuMuon.Name = "rdMaDG_PhieuMuon";
            this.rdMaDG_PhieuMuon.Size = new System.Drawing.Size(109, 23);
            this.rdMaDG_PhieuMuon.TabIndex = 42;
            this.rdMaDG_PhieuMuon.TabStop = true;
            this.rdMaDG_PhieuMuon.Text = "Mã Độc Giả";
            this.rdMaDG_PhieuMuon.UseVisualStyleBackColor = true;
            // 
            // txtSearchPM
            // 
            this.txtSearchPM.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPM.Location = new System.Drawing.Point(314, 27);
            this.txtSearchPM.Name = "txtSearchPM";
            this.txtSearchPM.Size = new System.Drawing.Size(150, 26);
            this.txtSearchPM.TabIndex = 41;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(14, 29);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(113, 20);
            this.label47.TabIndex = 40;
            this.label47.Text = "Tìm Kiếm Theo :";
            // 
            // tabThemPhieuMuon
            // 
            this.tabThemPhieuMuon.BackColor = System.Drawing.SystemColors.Control;
            this.tabThemPhieuMuon.Controls.Add(this.lbMaDocGiaPhieuMuon);
            this.tabThemPhieuMuon.Controls.Add(this.lbMaDocGia);
            this.tabThemPhieuMuon.Controls.Add(this.lbMaTLPhieuMuon);
            this.tabThemPhieuMuon.Controls.Add(this.lbMaTaiLieuPhieuMuon);
            this.tabThemPhieuMuon.Controls.Add(this.lbListSachMuonHide);
            this.tabThemPhieuMuon.Controls.Add(this.btnXoaMTLTrongList);
            this.tabThemPhieuMuon.Controls.Add(this.btnAddMTLVaoList);
            this.tabThemPhieuMuon.Controls.Add(this.label28);
            this.tabThemPhieuMuon.Controls.Add(this.cbxMaTLPM);
            this.tabThemPhieuMuon.Controls.Add(this.label22);
            this.tabThemPhieuMuon.Controls.Add(this.label16);
            this.tabThemPhieuMuon.Controls.Add(this.cbxMaDGPM);
            this.tabThemPhieuMuon.Controls.Add(this.lbListSachMuon);
            this.tabThemPhieuMuon.Controls.Add(this.btnThem_PhieuMuon);
            this.tabThemPhieuMuon.Location = new System.Drawing.Point(4, 32);
            this.tabThemPhieuMuon.Name = "tabThemPhieuMuon";
            this.tabThemPhieuMuon.Padding = new System.Windows.Forms.Padding(3);
            this.tabThemPhieuMuon.Size = new System.Drawing.Size(895, 398);
            this.tabThemPhieuMuon.TabIndex = 0;
            this.tabThemPhieuMuon.Text = "Thêm Phiếu Mượn";
            // 
            // lbMaDocGiaPhieuMuon
            // 
            this.lbMaDocGiaPhieuMuon.AutoSize = true;
            this.lbMaDocGiaPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaDocGiaPhieuMuon.Location = new System.Drawing.Point(158, 3);
            this.lbMaDocGiaPhieuMuon.Name = "lbMaDocGiaPhieuMuon";
            this.lbMaDocGiaPhieuMuon.Size = new System.Drawing.Size(0, 17);
            this.lbMaDocGiaPhieuMuon.TabIndex = 45;
            // 
            // lbMaDocGia
            // 
            this.lbMaDocGia.AutoSize = true;
            this.lbMaDocGia.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaDocGia.Location = new System.Drawing.Point(21, 8);
            this.lbMaDocGia.Name = "lbMaDocGia";
            this.lbMaDocGia.Size = new System.Drawing.Size(84, 17);
            this.lbMaDocGia.TabIndex = 44;
            this.lbMaDocGia.Text = "Mã Độc Giả :";
            // 
            // lbMaTLPhieuMuon
            // 
            this.lbMaTLPhieuMuon.AutoSize = true;
            this.lbMaTLPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaTLPhieuMuon.Location = new System.Drawing.Point(158, 63);
            this.lbMaTLPhieuMuon.Name = "lbMaTLPhieuMuon";
            this.lbMaTLPhieuMuon.Size = new System.Drawing.Size(0, 17);
            this.lbMaTLPhieuMuon.TabIndex = 43;
            // 
            // lbMaTaiLieuPhieuMuon
            // 
            this.lbMaTaiLieuPhieuMuon.AutoSize = true;
            this.lbMaTaiLieuPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaTaiLieuPhieuMuon.Location = new System.Drawing.Point(22, 67);
            this.lbMaTaiLieuPhieuMuon.Name = "lbMaTaiLieuPhieuMuon";
            this.lbMaTaiLieuPhieuMuon.Size = new System.Drawing.Size(84, 17);
            this.lbMaTaiLieuPhieuMuon.TabIndex = 42;
            this.lbMaTaiLieuPhieuMuon.Text = "Mã Tài Liệu :";
            // 
            // lbListSachMuonHide
            // 
            this.lbListSachMuonHide.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbListSachMuonHide.FormattingEnabled = true;
            this.lbListSachMuonHide.ItemHeight = 17;
            this.lbListSachMuonHide.Location = new System.Drawing.Point(695, 45);
            this.lbListSachMuonHide.Name = "lbListSachMuonHide";
            this.lbListSachMuonHide.Size = new System.Drawing.Size(120, 89);
            this.lbListSachMuonHide.TabIndex = 41;
            // 
            // btnXoaMTLTrongList
            // 
            this.btnXoaMTLTrongList.BackColor = System.Drawing.Color.Teal;
            this.btnXoaMTLTrongList.FlatAppearance.BorderSize = 0;
            this.btnXoaMTLTrongList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaMTLTrongList.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaMTLTrongList.Location = new System.Drawing.Point(570, 176);
            this.btnXoaMTLTrongList.Name = "btnXoaMTLTrongList";
            this.btnXoaMTLTrongList.Size = new System.Drawing.Size(85, 30);
            this.btnXoaMTLTrongList.TabIndex = 40;
            this.btnXoaMTLTrongList.Text = "Xóa";
            this.btnXoaMTLTrongList.UseVisualStyleBackColor = false;
            this.btnXoaMTLTrongList.Click += new System.EventHandler(this.btnXoaMTLTrongList_Click);
            // 
            // btnAddMTLVaoList
            // 
            this.btnAddMTLVaoList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(141)))), ((int)(((byte)(172)))));
            this.btnAddMTLVaoList.FlatAppearance.BorderSize = 0;
            this.btnAddMTLVaoList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddMTLVaoList.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMTLVaoList.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddMTLVaoList.Location = new System.Drawing.Point(570, 85);
            this.btnAddMTLVaoList.Name = "btnAddMTLVaoList";
            this.btnAddMTLVaoList.Size = new System.Drawing.Size(85, 30);
            this.btnAddMTLVaoList.TabIndex = 39;
            this.btnAddMTLVaoList.Text = "Thêm";
            this.btnAddMTLVaoList.UseVisualStyleBackColor = false;
            this.btnAddMTLVaoList.Click += new System.EventHandler(this.btnAddMTLVaoList_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(22, 100);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(87, 17);
            this.label28.TabIndex = 38;
            this.label28.Text = "Tên Tài Liệu :";
            // 
            // cbxMaTLPM
            // 
            this.cbxMaTLPM.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbxMaTLPM.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxMaTLPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxMaTLPM.FormattingEnabled = true;
            this.cbxMaTLPM.Location = new System.Drawing.Point(180, 92);
            this.cbxMaTLPM.Name = "cbxMaTLPM";
            this.cbxMaTLPM.Size = new System.Drawing.Size(362, 24);
            this.cbxMaTLPM.TabIndex = 37;
            this.cbxMaTLPM.SelectedIndexChanged += new System.EventHandler(this.cbxMaTLPM_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(22, 147);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(151, 17);
            this.label22.TabIndex = 36;
            this.label22.Text = "Danh Sách Sách Mượn";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(21, 35);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 17);
            this.label16.TabIndex = 35;
            this.label16.Text = "Tên Độc Giả :";
            // 
            // cbxMaDGPM
            // 
            this.cbxMaDGPM.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbxMaDGPM.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxMaDGPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxMaDGPM.FormattingEnabled = true;
            this.cbxMaDGPM.Location = new System.Drawing.Point(180, 32);
            this.cbxMaDGPM.Name = "cbxMaDGPM";
            this.cbxMaDGPM.Size = new System.Drawing.Size(362, 24);
            this.cbxMaDGPM.TabIndex = 34;
            this.cbxMaDGPM.SelectedIndexChanged += new System.EventHandler(this.cbxMaDGPM_SelectedIndexChanged);
            this.cbxMaDGPM.TextChanged += new System.EventHandler(this.cbxMaDGPM_TextChanged);
            // 
            // lbListSachMuon
            // 
            this.lbListSachMuon.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbListSachMuon.FormattingEnabled = true;
            this.lbListSachMuon.ItemHeight = 17;
            this.lbListSachMuon.Location = new System.Drawing.Point(180, 145);
            this.lbListSachMuon.Name = "lbListSachMuon";
            this.lbListSachMuon.Size = new System.Drawing.Size(362, 123);
            this.lbListSachMuon.TabIndex = 33;
            // 
            // btnThem_PhieuMuon
            // 
            this.btnThem_PhieuMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnThem_PhieuMuon.FlatAppearance.BorderSize = 0;
            this.btnThem_PhieuMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThem_PhieuMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThem_PhieuMuon.ForeColor = System.Drawing.Color.White;
            this.btnThem_PhieuMuon.Location = new System.Drawing.Point(312, 324);
            this.btnThem_PhieuMuon.Name = "btnThem_PhieuMuon";
            this.btnThem_PhieuMuon.Size = new System.Drawing.Size(143, 36);
            this.btnThem_PhieuMuon.TabIndex = 32;
            this.btnThem_PhieuMuon.Text = "Lập Phiếu Mượn";
            this.btnThem_PhieuMuon.UseVisualStyleBackColor = false;
            this.btnThem_PhieuMuon.Click += new System.EventHandler(this.btnThem_PhieuMuon_Click);
            // 
            // tabPhieuTra
            // 
            this.tabPhieuTra.BackColor = System.Drawing.SystemColors.Control;
            this.tabPhieuTra.Controls.Add(this.tbcPhieuTra);
            this.tabPhieuTra.Controls.Add(this.comboBox2);
            this.tabPhieuTra.Controls.Add(this.button18);
            this.tabPhieuTra.Controls.Add(this.button19);
            this.tabPhieuTra.Controls.Add(this.button23);
            this.tabPhieuTra.Controls.Add(this.button24);
            this.tabPhieuTra.Controls.Add(this.button25);
            this.tabPhieuTra.Controls.Add(this.button26);
            this.tabPhieuTra.Controls.Add(this.btnXoaPT);
            this.tabPhieuTra.Controls.Add(this.btnXemChiTietPT);
            this.tabPhieuTra.Controls.Add(this.dataGridView2);
            this.tabPhieuTra.Controls.Add(this.btnTimKiemPT);
            this.tabPhieuTra.Controls.Add(this.label48);
            this.tabPhieuTra.Controls.Add(this.radioButton4);
            this.tabPhieuTra.Controls.Add(this.radioButton5);
            this.tabPhieuTra.Controls.Add(this.radioButton6);
            this.tabPhieuTra.Controls.Add(this.textBox10);
            this.tabPhieuTra.Controls.Add(this.label49);
            this.tabPhieuTra.Location = new System.Drawing.Point(4, 32);
            this.tabPhieuTra.Name = "tabPhieuTra";
            this.tabPhieuTra.Size = new System.Drawing.Size(903, 434);
            this.tabPhieuTra.TabIndex = 5;
            this.tabPhieuTra.Text = "Phiếu Trả";
            // 
            // tbcPhieuTra
            // 
            this.tbcPhieuTra.Controls.Add(this.tabPage_TimkiemPhieuTra);
            this.tbcPhieuTra.Controls.Add(this.tabpage_ThemPhieuTra);
            this.tbcPhieuTra.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcPhieuTra.ItemSize = new System.Drawing.Size(104, 25);
            this.tbcPhieuTra.Location = new System.Drawing.Point(0, 0);
            this.tbcPhieuTra.Name = "tbcPhieuTra";
            this.tbcPhieuTra.SelectedIndex = 0;
            this.tbcPhieuTra.Size = new System.Drawing.Size(903, 434);
            this.tbcPhieuTra.TabIndex = 40;
            this.tbcPhieuTra.VisibleChanged += new System.EventHandler(this.frmHome_Load);
            // 
            // tabPage_TimkiemPhieuTra
            // 
            this.tabPage_TimkiemPhieuTra.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.rdMaPhieuMuon_PhieuTraTK);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnChinhSua_PhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnHuy_PhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnLuuPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnXemTatCaPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnXoaPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnXemChiTietPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.dgvPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.btnTimKiemPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.rdMaPhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.rdMaDG_PhieuTra);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.txtSearchPT);
            this.tabPage_TimkiemPhieuTra.Controls.Add(this.label67);
            this.tabPage_TimkiemPhieuTra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage_TimkiemPhieuTra.Location = new System.Drawing.Point(4, 29);
            this.tabPage_TimkiemPhieuTra.Name = "tabPage_TimkiemPhieuTra";
            this.tabPage_TimkiemPhieuTra.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_TimkiemPhieuTra.Size = new System.Drawing.Size(895, 401);
            this.tabPage_TimkiemPhieuTra.TabIndex = 1;
            this.tabPage_TimkiemPhieuTra.Text = "Tìm Kiếm Phiếu Trả";
            // 
            // rdMaPhieuMuon_PhieuTraTK
            // 
            this.rdMaPhieuMuon_PhieuTraTK.AutoSize = true;
            this.rdMaPhieuMuon_PhieuTraTK.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaPhieuMuon_PhieuTraTK.Location = new System.Drawing.Point(161, 27);
            this.rdMaPhieuMuon_PhieuTraTK.Name = "rdMaPhieuMuon_PhieuTraTK";
            this.rdMaPhieuMuon_PhieuTraTK.Size = new System.Drawing.Size(123, 21);
            this.rdMaPhieuMuon_PhieuTraTK.TabIndex = 56;
            this.rdMaPhieuMuon_PhieuTraTK.TabStop = true;
            this.rdMaPhieuMuon_PhieuTraTK.Text = "Mã Phiếu Mượn";
            this.rdMaPhieuMuon_PhieuTraTK.UseVisualStyleBackColor = true;
            // 
            // btnChinhSua_PhieuTra
            // 
            this.btnChinhSua_PhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnChinhSua_PhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChinhSua_PhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChinhSua_PhieuTra.ForeColor = System.Drawing.Color.White;
            this.btnChinhSua_PhieuTra.Location = new System.Drawing.Point(146, 341);
            this.btnChinhSua_PhieuTra.Name = "btnChinhSua_PhieuTra";
            this.btnChinhSua_PhieuTra.Size = new System.Drawing.Size(138, 43);
            this.btnChinhSua_PhieuTra.TabIndex = 55;
            this.btnChinhSua_PhieuTra.Text = "Chỉnh Sửa";
            this.btnChinhSua_PhieuTra.UseVisualStyleBackColor = false;
            this.btnChinhSua_PhieuTra.Click += new System.EventHandler(this.btnChinhSua_PhieuTra_Click);
            // 
            // btnHuy_PhieuTra
            // 
            this.btnHuy_PhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnHuy_PhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuy_PhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy_PhieuTra.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHuy_PhieuTra.Location = new System.Drawing.Point(658, 339);
            this.btnHuy_PhieuTra.Name = "btnHuy_PhieuTra";
            this.btnHuy_PhieuTra.Size = new System.Drawing.Size(114, 43);
            this.btnHuy_PhieuTra.TabIndex = 54;
            this.btnHuy_PhieuTra.Text = "Hủy";
            this.btnHuy_PhieuTra.UseVisualStyleBackColor = false;
            this.btnHuy_PhieuTra.Click += new System.EventHandler(this.btnHuy_PhieuTra_Click);
            // 
            // btnLuuPhieuTra
            // 
            this.btnLuuPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnLuuPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuuPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuPhieuTra.ForeColor = System.Drawing.Color.White;
            this.btnLuuPhieuTra.Location = new System.Drawing.Point(421, 339);
            this.btnLuuPhieuTra.Name = "btnLuuPhieuTra";
            this.btnLuuPhieuTra.Size = new System.Drawing.Size(138, 43);
            this.btnLuuPhieuTra.TabIndex = 53;
            this.btnLuuPhieuTra.Text = "Lưu";
            this.btnLuuPhieuTra.UseVisualStyleBackColor = false;
            this.btnLuuPhieuTra.Click += new System.EventHandler(this.btnLuuPhieuTra_Click);
            // 
            // btnXemTatCaPhieuTra
            // 
            this.btnXemTatCaPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemTatCaPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemTatCaPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemTatCaPhieuTra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemTatCaPhieuTra.Location = new System.Drawing.Point(618, 21);
            this.btnXemTatCaPhieuTra.Name = "btnXemTatCaPhieuTra";
            this.btnXemTatCaPhieuTra.Size = new System.Drawing.Size(116, 33);
            this.btnXemTatCaPhieuTra.TabIndex = 52;
            this.btnXemTatCaPhieuTra.Text = "Xem Tất Cả";
            this.btnXemTatCaPhieuTra.UseVisualStyleBackColor = false;
            this.btnXemTatCaPhieuTra.Click += new System.EventHandler(this.btnXemTatCaPhieuTra_Click);
            // 
            // btnXoaPhieuTra
            // 
            this.btnXoaPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXoaPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPhieuTra.ForeColor = System.Drawing.Color.White;
            this.btnXoaPhieuTra.Location = new System.Drawing.Point(303, 341);
            this.btnXoaPhieuTra.Name = "btnXoaPhieuTra";
            this.btnXoaPhieuTra.Size = new System.Drawing.Size(117, 41);
            this.btnXoaPhieuTra.TabIndex = 49;
            this.btnXoaPhieuTra.Text = "Xóa";
            this.btnXoaPhieuTra.UseVisualStyleBackColor = false;
            this.btnXoaPhieuTra.Click += new System.EventHandler(this.btnXoaPhieuTra_Click);
            // 
            // btnXemChiTietPhieuTra
            // 
            this.btnXemChiTietPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXemChiTietPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemChiTietPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemChiTietPhieuTra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemChiTietPhieuTra.Location = new System.Drawing.Point(17, 341);
            this.btnXemChiTietPhieuTra.Name = "btnXemChiTietPhieuTra";
            this.btnXemChiTietPhieuTra.Size = new System.Drawing.Size(117, 41);
            this.btnXemChiTietPhieuTra.TabIndex = 48;
            this.btnXemChiTietPhieuTra.Text = "Xem Chi Tiết";
            this.btnXemChiTietPhieuTra.UseVisualStyleBackColor = false;
            this.btnXemChiTietPhieuTra.Click += new System.EventHandler(this.btnXemChiTietPhieuTra_Click);
            // 
            // dgvPhieuTra
            // 
            this.dgvPhieuTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuTra.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPhieuTra.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPhieuTra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPhieuTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuTra.Location = new System.Drawing.Point(7, 86);
            this.dgvPhieuTra.Name = "dgvPhieuTra";
            this.dgvPhieuTra.Size = new System.Drawing.Size(840, 247);
            this.dgvPhieuTra.TabIndex = 47;
            // 
            // btnTimKiemPhieuTra
            // 
            this.btnTimKiemPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnTimKiemPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimKiemPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKiemPhieuTra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTimKiemPhieuTra.Image = ((System.Drawing.Image)(resources.GetObject("btnTimKiemPhieuTra.Image")));
            this.btnTimKiemPhieuTra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTimKiemPhieuTra.Location = new System.Drawing.Point(481, 21);
            this.btnTimKiemPhieuTra.Name = "btnTimKiemPhieuTra";
            this.btnTimKiemPhieuTra.Size = new System.Drawing.Size(123, 33);
            this.btnTimKiemPhieuTra.TabIndex = 46;
            this.btnTimKiemPhieuTra.Text = "Tìm Kiếm";
            this.btnTimKiemPhieuTra.UseVisualStyleBackColor = false;
            this.btnTimKiemPhieuTra.Click += new System.EventHandler(this.btnTimKiemPhieuTra_Click);
            // 
            // rdMaPhieuTra
            // 
            this.rdMaPhieuTra.AutoSize = true;
            this.rdMaPhieuTra.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaPhieuTra.Location = new System.Drawing.Point(161, 50);
            this.rdMaPhieuTra.Name = "rdMaPhieuTra";
            this.rdMaPhieuTra.Size = new System.Drawing.Size(106, 21);
            this.rdMaPhieuTra.TabIndex = 43;
            this.rdMaPhieuTra.TabStop = true;
            this.rdMaPhieuTra.Text = "Mã Phiếu Trả";
            this.rdMaPhieuTra.UseVisualStyleBackColor = true;
            // 
            // rdMaDG_PhieuTra
            // 
            this.rdMaDG_PhieuTra.AutoSize = true;
            this.rdMaDG_PhieuTra.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaDG_PhieuTra.Location = new System.Drawing.Point(161, 5);
            this.rdMaDG_PhieuTra.Name = "rdMaDG_PhieuTra";
            this.rdMaDG_PhieuTra.Size = new System.Drawing.Size(102, 21);
            this.rdMaDG_PhieuTra.TabIndex = 42;
            this.rdMaDG_PhieuTra.TabStop = true;
            this.rdMaDG_PhieuTra.Text = "Mã Độc Giả";
            this.rdMaDG_PhieuTra.UseVisualStyleBackColor = true;
            // 
            // txtSearchPT
            // 
            this.txtSearchPT.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPT.Location = new System.Drawing.Point(318, 27);
            this.txtSearchPT.Name = "txtSearchPT";
            this.txtSearchPT.Size = new System.Drawing.Size(122, 23);
            this.txtSearchPT.TabIndex = 41;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(14, 33);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(107, 17);
            this.label67.TabIndex = 40;
            this.label67.Text = "Tìm Kiếm Theo :";
            // 
            // tabpage_ThemPhieuTra
            // 
            this.tabpage_ThemPhieuTra.BackColor = System.Drawing.SystemColors.Control;
            this.tabpage_ThemPhieuTra.Controls.Add(this.lbDanhSachSachTraHide);
            this.tabpage_ThemPhieuTra.Controls.Add(this.btnXoaSachTra);
            this.tabpage_ThemPhieuTra.Controls.Add(this.btnAddSachTra);
            this.tabpage_ThemPhieuTra.Controls.Add(this.cbxSachPT);
            this.tabpage_ThemPhieuTra.Controls.Add(this.label15);
            this.tabpage_ThemPhieuTra.Controls.Add(this.groupBox5);
            this.tabpage_ThemPhieuTra.Controls.Add(this.cbxMaPMCuaPT);
            this.tabpage_ThemPhieuTra.Controls.Add(this.btnThemPhieuTra);
            this.tabpage_ThemPhieuTra.Controls.Add(this.label65);
            this.tabpage_ThemPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabpage_ThemPhieuTra.Location = new System.Drawing.Point(4, 29);
            this.tabpage_ThemPhieuTra.Name = "tabpage_ThemPhieuTra";
            this.tabpage_ThemPhieuTra.Padding = new System.Windows.Forms.Padding(3);
            this.tabpage_ThemPhieuTra.Size = new System.Drawing.Size(895, 401);
            this.tabpage_ThemPhieuTra.TabIndex = 0;
            this.tabpage_ThemPhieuTra.Text = "Thêm Phiếu Trả";
            // 
            // lbDanhSachSachTraHide
            // 
            this.lbDanhSachSachTraHide.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDanhSachSachTraHide.FormattingEnabled = true;
            this.lbDanhSachSachTraHide.ItemHeight = 17;
            this.lbDanhSachSachTraHide.Location = new System.Drawing.Point(648, 30);
            this.lbDanhSachSachTraHide.Name = "lbDanhSachSachTraHide";
            this.lbDanhSachSachTraHide.Size = new System.Drawing.Size(120, 89);
            this.lbDanhSachSachTraHide.TabIndex = 40;
            // 
            // btnXoaSachTra
            // 
            this.btnXoaSachTra.BackColor = System.Drawing.Color.Teal;
            this.btnXoaSachTra.FlatAppearance.BorderSize = 0;
            this.btnXoaSachTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaSachTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSachTra.Location = new System.Drawing.Point(404, 218);
            this.btnXoaSachTra.Name = "btnXoaSachTra";
            this.btnXoaSachTra.Size = new System.Drawing.Size(92, 26);
            this.btnXoaSachTra.TabIndex = 39;
            this.btnXoaSachTra.Text = "Xóa";
            this.btnXoaSachTra.UseVisualStyleBackColor = false;
            this.btnXoaSachTra.Click += new System.EventHandler(this.btnXoaSachTra_Click);
            // 
            // btnAddSachTra
            // 
            this.btnAddSachTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(141)))), ((int)(((byte)(172)))));
            this.btnAddSachTra.FlatAppearance.BorderSize = 0;
            this.btnAddSachTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddSachTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSachTra.Location = new System.Drawing.Point(404, 98);
            this.btnAddSachTra.Name = "btnAddSachTra";
            this.btnAddSachTra.Size = new System.Drawing.Size(92, 25);
            this.btnAddSachTra.TabIndex = 38;
            this.btnAddSachTra.Text = "Thêm";
            this.btnAddSachTra.UseVisualStyleBackColor = false;
            this.btnAddSachTra.Click += new System.EventHandler(this.btnAddSachTra_Click);
            // 
            // cbxSachPT
            // 
            this.cbxSachPT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbxSachPT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxSachPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbxSachPT.FormattingEnabled = true;
            this.cbxSachPT.Location = new System.Drawing.Point(207, 74);
            this.cbxSachPT.Name = "cbxSachPT";
            this.cbxSachPT.Size = new System.Drawing.Size(167, 23);
            this.cbxSachPT.TabIndex = 37;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(58, 79);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 17);
            this.label15.TabIndex = 36;
            this.label15.Text = "Sách Mang Trả :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbDanhSachSachTra);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(52, 123);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(313, 138);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Sách Mang Trả";
            // 
            // lbDanhSachSachTra
            // 
            this.lbDanhSachSachTra.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbDanhSachSachTra.FormattingEnabled = true;
            this.lbDanhSachSachTra.ItemHeight = 17;
            this.lbDanhSachSachTra.Location = new System.Drawing.Point(3, 29);
            this.lbDanhSachSachTra.Name = "lbDanhSachSachTra";
            this.lbDanhSachSachTra.Size = new System.Drawing.Size(307, 106);
            this.lbDanhSachSachTra.TabIndex = 34;
            // 
            // cbxMaPMCuaPT
            // 
            this.cbxMaPMCuaPT.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cbxMaPMCuaPT.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbxMaPMCuaPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbxMaPMCuaPT.FormattingEnabled = true;
            this.cbxMaPMCuaPT.Location = new System.Drawing.Point(206, 36);
            this.cbxMaPMCuaPT.Name = "cbxMaPMCuaPT";
            this.cbxMaPMCuaPT.Size = new System.Drawing.Size(168, 23);
            this.cbxMaPMCuaPT.TabIndex = 33;
            this.cbxMaPMCuaPT.SelectedIndexChanged += new System.EventHandler(this.cbxMaPMCuaPT_SelectedIndexChanged);
            this.cbxMaPMCuaPT.TextChanged += new System.EventHandler(this.cbxMaPMCuaPT_TextChanged);
            // 
            // btnThemPhieuTra
            // 
            this.btnThemPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnThemPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPhieuTra.ForeColor = System.Drawing.Color.White;
            this.btnThemPhieuTra.Location = new System.Drawing.Point(166, 309);
            this.btnThemPhieuTra.Name = "btnThemPhieuTra";
            this.btnThemPhieuTra.Size = new System.Drawing.Size(143, 36);
            this.btnThemPhieuTra.TabIndex = 32;
            this.btnThemPhieuTra.Text = "Lập Phiếu Trả";
            this.btnThemPhieuTra.UseVisualStyleBackColor = false;
            this.btnThemPhieuTra.Click += new System.EventHandler(this.btnThemPhieuTra_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(58, 39);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(113, 17);
            this.label65.TabIndex = 20;
            this.label65.Text = "Mã Phiếu Mượn :";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(408, 68);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 39;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(111, 354);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(138, 43);
            this.button18.TabIndex = 38;
            this.button18.Text = "Chỉnh Sửa";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button19.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button19.Location = new System.Drawing.Point(544, 353);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(133, 44);
            this.button19.TabIndex = 37;
            this.button19.Text = "Hủy";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(319, 354);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(138, 43);
            this.button23.TabIndex = 36;
            this.button23.Text = "Lưu";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Purple;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button24.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button24.Location = new System.Drawing.Point(703, 72);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(116, 33);
            this.button24.TabIndex = 35;
            this.button24.Text = "Xem Tất Cả";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Green;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button25.Location = new System.Drawing.Point(663, 354);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(176, 41);
            this.button25.TabIndex = 34;
            this.button25.Text = "Lập Phiếu Cảnh Cáo";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Green;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button26.Location = new System.Drawing.Point(497, 354);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(129, 41);
            this.button26.TabIndex = 33;
            this.button26.Text = "Lập Phiếu Trả";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // btnXoaPT
            // 
            this.btnXoaPT.BackColor = System.Drawing.Color.Green;
            this.btnXoaPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXoaPT.ForeColor = System.Drawing.Color.White;
            this.btnXoaPT.Location = new System.Drawing.Point(171, 354);
            this.btnXoaPT.Name = "btnXoaPT";
            this.btnXoaPT.Size = new System.Drawing.Size(117, 41);
            this.btnXoaPT.TabIndex = 32;
            this.btnXoaPT.Text = "Xóa";
            this.btnXoaPT.UseVisualStyleBackColor = false;
            // 
            // btnXemChiTietPT
            // 
            this.btnXemChiTietPT.BackColor = System.Drawing.Color.Green;
            this.btnXemChiTietPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnXemChiTietPT.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemChiTietPT.Location = new System.Drawing.Point(21, 354);
            this.btnXemChiTietPT.Name = "btnXemChiTietPT";
            this.btnXemChiTietPT.Size = new System.Drawing.Size(117, 41);
            this.btnXemChiTietPT.TabIndex = 31;
            this.btnXemChiTietPT.Text = "Xem Chi Tiết";
            this.btnXemChiTietPT.UseVisualStyleBackColor = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(11, 131);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(840, 199);
            this.dataGridView2.TabIndex = 30;
            // 
            // btnTimKiemPT
            // 
            this.btnTimKiemPT.BackColor = System.Drawing.Color.Purple;
            this.btnTimKiemPT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnTimKiemPT.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTimKiemPT.Location = new System.Drawing.Point(554, 72);
            this.btnTimKiemPT.Name = "btnTimKiemPT";
            this.btnTimKiemPT.Size = new System.Drawing.Size(123, 33);
            this.btnTimKiemPT.TabIndex = 29;
            this.btnTimKiemPT.Text = "Tìm Kiếm";
            this.btnTimKiemPT.UseVisualStyleBackColor = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(562, 36);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(115, 13);
            this.label48.TabIndex = 28;
            this.label48.Text = "CMND/MSSV/MSCB :";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(275, 108);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(61, 17);
            this.radioButton4.TabIndex = 27;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Họ Tên";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(275, 72);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(127, 17);
            this.radioButton5.TabIndex = 26;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "CMND/MSSV/MSCB";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(275, 36);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(82, 17);
            this.radioButton6.TabIndex = 25;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Mã Độc Giả";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(687, 33);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(122, 20);
            this.textBox10.TabIndex = 24;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label49.Location = new System.Drawing.Point(81, 50);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(168, 25);
            this.label49.TabIndex = 23;
            this.label49.Text = "Tìm Kiếm Theo :";
            // 
            // tabPhieuPhat
            // 
            this.tabPhieuPhat.BackColor = System.Drawing.SystemColors.Control;
            this.tabPhieuPhat.Controls.Add(this.rdMPP_PP);
            this.tabPhieuPhat.Controls.Add(this.cbxMaPMcuaPP);
            this.tabPhieuPhat.Controls.Add(this.btn_LapPhieuPhat);
            this.tabPhieuPhat.Controls.Add(this.lbMaPM_PP);
            this.tabPhieuPhat.Controls.Add(this.btnXemTatCaPhieuPhat);
            this.tabPhieuPhat.Controls.Add(this.btnXoaPP);
            this.tabPhieuPhat.Controls.Add(this.dgvPhieuPhat);
            this.tabPhieuPhat.Controls.Add(this.btnSearchPP);
            this.tabPhieuPhat.Controls.Add(this.rdMaPM_PP);
            this.tabPhieuPhat.Controls.Add(this.rdMDG_PP);
            this.tabPhieuPhat.Controls.Add(this.txtSearchMaPP);
            this.tabPhieuPhat.Controls.Add(this.label51);
            this.tabPhieuPhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabPhieuPhat.Location = new System.Drawing.Point(4, 32);
            this.tabPhieuPhat.Name = "tabPhieuPhat";
            this.tabPhieuPhat.Size = new System.Drawing.Size(903, 434);
            this.tabPhieuPhat.TabIndex = 6;
            this.tabPhieuPhat.Text = "Phiếu Phạt";
            // 
            // rdMPP_PP
            // 
            this.rdMPP_PP.AutoSize = true;
            this.rdMPP_PP.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMPP_PP.Location = new System.Drawing.Point(223, 73);
            this.rdMPP_PP.Name = "rdMPP_PP";
            this.rdMPP_PP.Size = new System.Drawing.Size(118, 21);
            this.rdMPP_PP.TabIndex = 51;
            this.rdMPP_PP.TabStop = true;
            this.rdMPP_PP.Text = "Mã Phiếu Phạt";
            this.rdMPP_PP.UseVisualStyleBackColor = true;
            // 
            // cbxMaPMcuaPP
            // 
            this.cbxMaPMcuaPP.FormattingEnabled = true;
            this.cbxMaPMcuaPP.Location = new System.Drawing.Point(671, 363);
            this.cbxMaPMcuaPP.Name = "cbxMaPMcuaPP";
            this.cbxMaPMcuaPP.Size = new System.Drawing.Size(146, 23);
            this.cbxMaPMcuaPP.TabIndex = 50;
            this.cbxMaPMcuaPP.Visible = false;
            // 
            // btn_LapPhieuPhat
            // 
            this.btn_LapPhieuPhat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btn_LapPhieuPhat.FlatAppearance.BorderSize = 0;
            this.btn_LapPhieuPhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LapPhieuPhat.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LapPhieuPhat.ForeColor = System.Drawing.Color.White;
            this.btn_LapPhieuPhat.Location = new System.Drawing.Point(372, 357);
            this.btn_LapPhieuPhat.Name = "btn_LapPhieuPhat";
            this.btn_LapPhieuPhat.Size = new System.Drawing.Size(143, 36);
            this.btn_LapPhieuPhat.TabIndex = 49;
            this.btn_LapPhieuPhat.Text = "Lập Phiếu Phạt";
            this.btn_LapPhieuPhat.UseVisualStyleBackColor = false;
            this.btn_LapPhieuPhat.Click += new System.EventHandler(this.btn_LapPhieuPhat_Click);
            // 
            // lbMaPM_PP
            // 
            this.lbMaPM_PP.AutoSize = true;
            this.lbMaPM_PP.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMaPM_PP.Location = new System.Drawing.Point(533, 366);
            this.lbMaPM_PP.Name = "lbMaPM_PP";
            this.lbMaPM_PP.Size = new System.Drawing.Size(113, 17);
            this.lbMaPM_PP.TabIndex = 48;
            this.lbMaPM_PP.Text = "Mã Phiếu Mượn :";
            this.lbMaPM_PP.Visible = false;
            // 
            // btnXemTatCaPhieuPhat
            // 
            this.btnXemTatCaPhieuPhat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemTatCaPhieuPhat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemTatCaPhieuPhat.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemTatCaPhieuPhat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemTatCaPhieuPhat.Location = new System.Drawing.Point(693, 34);
            this.btnXemTatCaPhieuPhat.Name = "btnXemTatCaPhieuPhat";
            this.btnXemTatCaPhieuPhat.Size = new System.Drawing.Size(116, 33);
            this.btnXemTatCaPhieuPhat.TabIndex = 35;
            this.btnXemTatCaPhieuPhat.Text = "Xem Tất Cả";
            this.btnXemTatCaPhieuPhat.UseVisualStyleBackColor = false;
            this.btnXemTatCaPhieuPhat.Click += new System.EventHandler(this.btnXemTatCaPhieuPhat_Click);
            // 
            // btnXoaPP
            // 
            this.btnXoaPP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXoaPP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaPP.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPP.ForeColor = System.Drawing.Color.White;
            this.btnXoaPP.Location = new System.Drawing.Point(203, 354);
            this.btnXoaPP.Name = "btnXoaPP";
            this.btnXoaPP.Size = new System.Drawing.Size(117, 41);
            this.btnXoaPP.TabIndex = 32;
            this.btnXoaPP.Text = "Xóa";
            this.btnXoaPP.UseVisualStyleBackColor = false;
            this.btnXoaPP.Click += new System.EventHandler(this.btnXoaPP_Click);
            // 
            // dgvPhieuPhat
            // 
            this.dgvPhieuPhat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuPhat.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPhieuPhat.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPhieuPhat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPhieuPhat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuPhat.Location = new System.Drawing.Point(11, 131);
            this.dgvPhieuPhat.Name = "dgvPhieuPhat";
            this.dgvPhieuPhat.Size = new System.Drawing.Size(840, 199);
            this.dgvPhieuPhat.TabIndex = 30;
            // 
            // btnSearchPP
            // 
            this.btnSearchPP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSearchPP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchPP.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchPP.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearchPP.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchPP.Image")));
            this.btnSearchPP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearchPP.Location = new System.Drawing.Point(536, 33);
            this.btnSearchPP.Name = "btnSearchPP";
            this.btnSearchPP.Size = new System.Drawing.Size(123, 33);
            this.btnSearchPP.TabIndex = 29;
            this.btnSearchPP.Text = "Tìm Kiếm";
            this.btnSearchPP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearchPP.UseVisualStyleBackColor = false;
            this.btnSearchPP.Click += new System.EventHandler(this.btnSearchPP_Click);
            // 
            // rdMaPM_PP
            // 
            this.rdMaPM_PP.AutoSize = true;
            this.rdMaPM_PP.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaPM_PP.Location = new System.Drawing.Point(223, 9);
            this.rdMaPM_PP.Name = "rdMaPM_PP";
            this.rdMaPM_PP.Size = new System.Drawing.Size(123, 21);
            this.rdMaPM_PP.TabIndex = 26;
            this.rdMaPM_PP.TabStop = true;
            this.rdMaPM_PP.Text = "Mã Phiếu Mượn";
            this.rdMaPM_PP.UseVisualStyleBackColor = true;
            // 
            // rdMDG_PP
            // 
            this.rdMDG_PP.AutoSize = true;
            this.rdMDG_PP.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMDG_PP.Location = new System.Drawing.Point(223, 41);
            this.rdMDG_PP.Name = "rdMDG_PP";
            this.rdMDG_PP.Size = new System.Drawing.Size(102, 21);
            this.rdMDG_PP.TabIndex = 25;
            this.rdMDG_PP.TabStop = true;
            this.rdMDG_PP.Text = "Mã Độc Giả";
            this.rdMDG_PP.UseVisualStyleBackColor = true;
            // 
            // txtSearchMaPP
            // 
            this.txtSearchMaPP.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchMaPP.Location = new System.Drawing.Point(374, 39);
            this.txtSearchMaPP.Name = "txtSearchMaPP";
            this.txtSearchMaPP.Size = new System.Drawing.Size(122, 23);
            this.txtSearchMaPP.TabIndex = 24;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(81, 50);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(107, 17);
            this.label51.TabIndex = 23;
            this.label51.Text = "Tìm Kiếm Theo :";
            // 
            // tabPhieuNhacNho
            // 
            this.tabPhieuNhacNho.BackColor = System.Drawing.SystemColors.Control;
            this.tabPhieuNhacNho.Controls.Add(this.label7);
            this.tabPhieuNhacNho.Controls.Add(this.txtMaPNN);
            this.tabPhieuNhacNho.Controls.Add(this.btnSearchPNN);
            this.tabPhieuNhacNho.Controls.Add(this.btnChinhSuaPNN);
            this.tabPhieuNhacNho.Controls.Add(this.cbxmaDocGiaNN);
            this.tabPhieuNhacNho.Controls.Add(this.btnXemTatCaPhieuNhacNho);
            this.tabPhieuNhacNho.Controls.Add(this.btnXoaPhieuNN);
            this.tabPhieuNhacNho.Controls.Add(this.dgvPhieuNhacNho);
            this.tabPhieuNhacNho.Controls.Add(this.btnThemPhieuNhacNho);
            this.tabPhieuNhacNho.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tabPhieuNhacNho.Location = new System.Drawing.Point(4, 32);
            this.tabPhieuNhacNho.Name = "tabPhieuNhacNho";
            this.tabPhieuNhacNho.Size = new System.Drawing.Size(903, 434);
            this.tabPhieuNhacNho.TabIndex = 7;
            this.tabPhieuNhacNho.Text = "Phiếu Nhắc Nhở";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(278, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 17);
            this.label7.TabIndex = 40;
            this.label7.Text = "Mã Độc Giả";
            // 
            // txtMaPNN
            // 
            this.txtMaPNN.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaPNN.Location = new System.Drawing.Point(359, 36);
            this.txtMaPNN.Name = "txtMaPNN";
            this.txtMaPNN.Size = new System.Drawing.Size(100, 22);
            this.txtMaPNN.TabIndex = 39;
            // 
            // btnSearchPNN
            // 
            this.btnSearchPNN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSearchPNN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchPNN.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchPNN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearchPNN.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchPNN.Image")));
            this.btnSearchPNN.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearchPNN.Location = new System.Drawing.Point(500, 29);
            this.btnSearchPNN.Name = "btnSearchPNN";
            this.btnSearchPNN.Size = new System.Drawing.Size(116, 33);
            this.btnSearchPNN.TabIndex = 38;
            this.btnSearchPNN.Text = "Tìm Kiếm";
            this.btnSearchPNN.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearchPNN.UseVisualStyleBackColor = false;
            this.btnSearchPNN.Click += new System.EventHandler(this.btnSearchPNN_Click);
            // 
            // btnChinhSuaPNN
            // 
            this.btnChinhSuaPNN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnChinhSuaPNN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChinhSuaPNN.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChinhSuaPNN.ForeColor = System.Drawing.Color.White;
            this.btnChinhSuaPNN.Location = new System.Drawing.Point(45, 379);
            this.btnChinhSuaPNN.Name = "btnChinhSuaPNN";
            this.btnChinhSuaPNN.Size = new System.Drawing.Size(117, 34);
            this.btnChinhSuaPNN.TabIndex = 37;
            this.btnChinhSuaPNN.Text = "Chỉnh Sửa";
            this.btnChinhSuaPNN.UseVisualStyleBackColor = false;
            this.btnChinhSuaPNN.Click += new System.EventHandler(this.btnChinhSuaPNN_Click);
            // 
            // cbxmaDocGiaNN
            // 
            this.cbxmaDocGiaNN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbxmaDocGiaNN.FormattingEnabled = true;
            this.cbxmaDocGiaNN.Location = new System.Drawing.Point(569, 384);
            this.cbxmaDocGiaNN.Name = "cbxmaDocGiaNN";
            this.cbxmaDocGiaNN.Size = new System.Drawing.Size(121, 23);
            this.cbxmaDocGiaNN.TabIndex = 36;
            // 
            // btnXemTatCaPhieuNhacNho
            // 
            this.btnXemTatCaPhieuNhacNho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemTatCaPhieuNhacNho.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemTatCaPhieuNhacNho.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemTatCaPhieuNhacNho.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemTatCaPhieuNhacNho.Location = new System.Drawing.Point(654, 27);
            this.btnXemTatCaPhieuNhacNho.Name = "btnXemTatCaPhieuNhacNho";
            this.btnXemTatCaPhieuNhacNho.Size = new System.Drawing.Size(116, 33);
            this.btnXemTatCaPhieuNhacNho.TabIndex = 35;
            this.btnXemTatCaPhieuNhacNho.Text = "Xem Tất Cả";
            this.btnXemTatCaPhieuNhacNho.UseVisualStyleBackColor = false;
            this.btnXemTatCaPhieuNhacNho.Click += new System.EventHandler(this.btnXemTatCaPhieuNhacNho_Click);
            // 
            // btnXoaPhieuNN
            // 
            this.btnXoaPhieuNN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnXoaPhieuNN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaPhieuNN.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPhieuNN.ForeColor = System.Drawing.Color.White;
            this.btnXoaPhieuNN.Location = new System.Drawing.Point(195, 378);
            this.btnXoaPhieuNN.Name = "btnXoaPhieuNN";
            this.btnXoaPhieuNN.Size = new System.Drawing.Size(117, 37);
            this.btnXoaPhieuNN.TabIndex = 32;
            this.btnXoaPhieuNN.Text = "Xóa";
            this.btnXoaPhieuNN.UseVisualStyleBackColor = false;
            this.btnXoaPhieuNN.Click += new System.EventHandler(this.btnXoaPhieuNN_Click);
            // 
            // dgvPhieuNhacNho
            // 
            this.dgvPhieuNhacNho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuNhacNho.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPhieuNhacNho.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvPhieuNhacNho.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPhieuNhacNho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhieuNhacNho.Location = new System.Drawing.Point(12, 119);
            this.dgvPhieuNhacNho.Name = "dgvPhieuNhacNho";
            this.dgvPhieuNhacNho.Size = new System.Drawing.Size(840, 222);
            this.dgvPhieuNhacNho.TabIndex = 30;
            // 
            // btnThemPhieuNhacNho
            // 
            this.btnThemPhieuNhacNho.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(72)))), ((int)(((byte)(129)))));
            this.btnThemPhieuNhacNho.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemPhieuNhacNho.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPhieuNhacNho.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnThemPhieuNhacNho.Location = new System.Drawing.Point(351, 379);
            this.btnThemPhieuNhacNho.Name = "btnThemPhieuNhacNho";
            this.btnThemPhieuNhacNho.Size = new System.Drawing.Size(183, 33);
            this.btnThemPhieuNhacNho.TabIndex = 29;
            this.btnThemPhieuNhacNho.Text = "Thêm Phiếu Nhắc Nhở";
            this.btnThemPhieuNhacNho.UseVisualStyleBackColor = false;
            this.btnThemPhieuNhacNho.Click += new System.EventHandler(this.btnThemPhieuNhacNho_Click);
            // 
            // panelQuanTriAdmin
            // 
            this.panelQuanTriAdmin.Controls.Add(this.tbcQuanTriAdmin);
            this.panelQuanTriAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panelQuanTriAdmin.Location = new System.Drawing.Point(1002, 31);
            this.panelQuanTriAdmin.Name = "panelQuanTriAdmin";
            this.panelQuanTriAdmin.Size = new System.Drawing.Size(911, 470);
            this.panelQuanTriAdmin.TabIndex = 17;
            this.panelQuanTriAdmin.Visible = false;
            // 
            // tbcQuanTriAdmin
            // 
            this.tbcQuanTriAdmin.Controls.Add(this.tbcAdmin_DocGia);
            this.tbcQuanTriAdmin.Controls.Add(this.tbcAdmin_NhanVien);
            this.tbcQuanTriAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcQuanTriAdmin.ItemSize = new System.Drawing.Size(88, 28);
            this.tbcQuanTriAdmin.Location = new System.Drawing.Point(0, 0);
            this.tbcQuanTriAdmin.Name = "tbcQuanTriAdmin";
            this.tbcQuanTriAdmin.SelectedIndex = 0;
            this.tbcQuanTriAdmin.Size = new System.Drawing.Size(911, 470);
            this.tbcQuanTriAdmin.TabIndex = 0;
            this.tbcQuanTriAdmin.Click += new System.EventHandler(this.tbcQuanTriAdmin_Click);
            // 
            // tbcAdmin_DocGia
            // 
            this.tbcAdmin_DocGia.BackColor = System.Drawing.SystemColors.Control;
            this.tbcAdmin_DocGia.Controls.Add(this.dgvLoaiDocGia);
            this.tbcAdmin_DocGia.Controls.Add(this.groupBox6);
            this.tbcAdmin_DocGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbcAdmin_DocGia.Location = new System.Drawing.Point(4, 32);
            this.tbcAdmin_DocGia.Name = "tbcAdmin_DocGia";
            this.tbcAdmin_DocGia.Padding = new System.Windows.Forms.Padding(3);
            this.tbcAdmin_DocGia.Size = new System.Drawing.Size(903, 434);
            this.tbcAdmin_DocGia.TabIndex = 0;
            this.tbcAdmin_DocGia.Text = "Loại Độc Giả";
            // 
            // dgvLoaiDocGia
            // 
            this.dgvLoaiDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLoaiDocGia.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvLoaiDocGia.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvLoaiDocGia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvLoaiDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoaiDocGia.Location = new System.Drawing.Point(21, 240);
            this.dgvLoaiDocGia.Name = "dgvLoaiDocGia";
            this.dgvLoaiDocGia.Size = new System.Drawing.Size(854, 188);
            this.dgvLoaiDocGia.TabIndex = 4;
            this.dgvLoaiDocGia.Click += new System.EventHandler(this.dgvLoaiDocGia_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtADTLDB);
            this.groupBox6.Controls.Add(this.txtADTDG);
            this.groupBox6.Controls.Add(this.btnADTLDG);
            this.groupBox6.Controls.Add(this.btnADCNLDG);
            this.groupBox6.Controls.Add(this.txtADPTN);
            this.groupBox6.Controls.Add(this.txtADSSM);
            this.groupBox6.Controls.Add(this.txtADSoNM);
            this.groupBox6.Controls.Add(this.txtADMaLoai);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox6.Location = new System.Drawing.Point(24, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(853, 206);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Loại Độc Giả";
            // 
            // txtADTLDB
            // 
            this.txtADTLDB.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADTLDB.Location = new System.Drawing.Point(621, 112);
            this.txtADTLDB.Name = "txtADTLDB";
            this.txtADTLDB.Size = new System.Drawing.Size(175, 23);
            this.txtADTLDB.TabIndex = 15;
            // 
            // txtADTDG
            // 
            this.txtADTDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADTDG.Location = new System.Drawing.Point(113, 28);
            this.txtADTDG.Name = "txtADTDG";
            this.txtADTDG.Size = new System.Drawing.Size(166, 23);
            this.txtADTDG.TabIndex = 14;
            // 
            // btnADTLDG
            // 
            this.btnADTLDG.BackColor = System.Drawing.Color.Teal;
            this.btnADTLDG.FlatAppearance.BorderSize = 0;
            this.btnADTLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnADTLDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADTLDG.ForeColor = System.Drawing.Color.White;
            this.btnADTLDG.Location = new System.Drawing.Point(430, 164);
            this.btnADTLDG.Name = "btnADTLDG";
            this.btnADTLDG.Size = new System.Drawing.Size(94, 30);
            this.btnADTLDG.TabIndex = 13;
            this.btnADTLDG.Text = "Thêm";
            this.btnADTLDG.UseVisualStyleBackColor = false;
            this.btnADTLDG.Click += new System.EventHandler(this.btnADTLDG_Click);
            // 
            // btnADCNLDG
            // 
            this.btnADCNLDG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(130)))), ((int)(((byte)(100)))));
            this.btnADCNLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnADCNLDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnADCNLDG.ForeColor = System.Drawing.Color.White;
            this.btnADCNLDG.Location = new System.Drawing.Point(280, 164);
            this.btnADCNLDG.Name = "btnADCNLDG";
            this.btnADCNLDG.Size = new System.Drawing.Size(91, 30);
            this.btnADCNLDG.TabIndex = 12;
            this.btnADCNLDG.Text = "Cập Nhật";
            this.btnADCNLDG.UseVisualStyleBackColor = false;
            this.btnADCNLDG.Click += new System.EventHandler(this.btnADCNLDG_Click);
            // 
            // txtADPTN
            // 
            this.txtADPTN.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADPTN.Location = new System.Drawing.Point(620, 72);
            this.txtADPTN.Name = "txtADPTN";
            this.txtADPTN.Size = new System.Drawing.Size(176, 23);
            this.txtADPTN.TabIndex = 10;
            // 
            // txtADSSM
            // 
            this.txtADSSM.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADSSM.Location = new System.Drawing.Point(621, 29);
            this.txtADSSM.Name = "txtADSSM";
            this.txtADSSM.Size = new System.Drawing.Size(175, 23);
            this.txtADSSM.TabIndex = 9;
            // 
            // txtADSoNM
            // 
            this.txtADSoNM.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADSoNM.Location = new System.Drawing.Point(113, 116);
            this.txtADSoNM.Name = "txtADSoNM";
            this.txtADSoNM.Size = new System.Drawing.Size(166, 23);
            this.txtADSoNM.TabIndex = 8;
            // 
            // txtADMaLoai
            // 
            this.txtADMaLoai.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtADMaLoai.Location = new System.Drawing.Point(113, 71);
            this.txtADMaLoai.Name = "txtADMaLoai";
            this.txtADMaLoai.Size = new System.Drawing.Size(166, 23);
            this.txtADMaLoai.TabIndex = 7;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(439, 117);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(149, 17);
            this.label32.TabIndex = 5;
            this.label32.Text = "Mượn Tài Liệu Đặc Biệt";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(439, 77);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 17);
            this.label31.TabIndex = 4;
            this.label31.Text = "Phí Thường Niên";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(439, 34);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 17);
            this.label26.TabIndex = 3;
            this.label26.Text = "Số Sách Mượn";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(10, 119);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(98, 17);
            this.label25.TabIndex = 2;
            this.label25.Text = "Số ngày mượn";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(13, 79);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 17);
            this.label24.TabIndex = 1;
            this.label24.Text = "Mã Loại";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(13, 35);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(85, 17);
            this.label23.TabIndex = 0;
            this.label23.Text = "Tên Độc Giả";
            // 
            // tbcAdmin_NhanVien
            // 
            this.tbcAdmin_NhanVien.BackColor = System.Drawing.SystemColors.Control;
            this.tbcAdmin_NhanVien.Controls.Add(this.txtMatKhauNVCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.txtHoTenNVCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.txtTenDangNhapNVCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.txtCaTrucNVCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.txtSearchPhieuMuon);
            this.tbcAdmin_NhanVien.Controls.Add(this.label21);
            this.tbcAdmin_NhanVien.Controls.Add(this.rdAdminCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.rdThuThuCapNhat);
            this.tbcAdmin_NhanVien.Controls.Add(this.label20);
            this.tbcAdmin_NhanVien.Controls.Add(this.btnCapNhatNhanVien);
            this.tbcAdmin_NhanVien.Controls.Add(this.label19);
            this.tbcAdmin_NhanVien.Controls.Add(this.label18);
            this.tbcAdmin_NhanVien.Controls.Add(this.label17);
            this.tbcAdmin_NhanVien.Controls.Add(this.label8);
            this.tbcAdmin_NhanVien.Controls.Add(this.btnXoaNV);
            this.tbcAdmin_NhanVien.Controls.Add(this.dgvNhanVien);
            this.tbcAdmin_NhanVien.Location = new System.Drawing.Point(4, 32);
            this.tbcAdmin_NhanVien.Name = "tbcAdmin_NhanVien";
            this.tbcAdmin_NhanVien.Padding = new System.Windows.Forms.Padding(3);
            this.tbcAdmin_NhanVien.Size = new System.Drawing.Size(903, 434);
            this.tbcAdmin_NhanVien.TabIndex = 1;
            this.tbcAdmin_NhanVien.Text = "Nhân Viên";
            // 
            // txtMatKhauNVCapNhat
            // 
            this.txtMatKhauNVCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhauNVCapNhat.Location = new System.Drawing.Point(503, 75);
            this.txtMatKhauNVCapNhat.Name = "txtMatKhauNVCapNhat";
            this.txtMatKhauNVCapNhat.Size = new System.Drawing.Size(207, 22);
            this.txtMatKhauNVCapNhat.TabIndex = 58;
            // 
            // txtHoTenNVCapNhat
            // 
            this.txtHoTenNVCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTenNVCapNhat.Location = new System.Drawing.Point(503, 29);
            this.txtHoTenNVCapNhat.Name = "txtHoTenNVCapNhat";
            this.txtHoTenNVCapNhat.Size = new System.Drawing.Size(204, 22);
            this.txtHoTenNVCapNhat.TabIndex = 52;
            // 
            // txtTenDangNhapNVCapNhat
            // 
            this.txtTenDangNhapNVCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDangNhapNVCapNhat.Location = new System.Drawing.Point(170, 75);
            this.txtTenDangNhapNVCapNhat.Name = "txtTenDangNhapNVCapNhat";
            this.txtTenDangNhapNVCapNhat.Size = new System.Drawing.Size(204, 22);
            this.txtTenDangNhapNVCapNhat.TabIndex = 50;
            // 
            // txtCaTrucNVCapNhat
            // 
            this.txtCaTrucNVCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCaTrucNVCapNhat.Location = new System.Drawing.Point(166, 141);
            this.txtCaTrucNVCapNhat.Name = "txtCaTrucNVCapNhat";
            this.txtCaTrucNVCapNhat.Size = new System.Drawing.Size(207, 22);
            this.txtCaTrucNVCapNhat.TabIndex = 48;
            // 
            // txtSearchPhieuMuon
            // 
            this.txtSearchPhieuMuon.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPhieuMuon.Location = new System.Drawing.Point(170, 29);
            this.txtSearchPhieuMuon.Name = "txtSearchPhieuMuon";
            this.txtSearchPhieuMuon.Size = new System.Drawing.Size(207, 22);
            this.txtSearchPhieuMuon.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(430, 78);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 17);
            this.label21.TabIndex = 57;
            this.label21.Text = "Mật Khẩu :";
            // 
            // rdAdminCapNhat
            // 
            this.rdAdminCapNhat.AutoSize = true;
            this.rdAdminCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdAdminCapNhat.Location = new System.Drawing.Point(532, 163);
            this.rdAdminCapNhat.Name = "rdAdminCapNhat";
            this.rdAdminCapNhat.Size = new System.Drawing.Size(64, 21);
            this.rdAdminCapNhat.TabIndex = 56;
            this.rdAdminCapNhat.TabStop = true;
            this.rdAdminCapNhat.Text = "Admin";
            this.rdAdminCapNhat.UseVisualStyleBackColor = true;
            // 
            // rdThuThuCapNhat
            // 
            this.rdThuThuCapNhat.AutoSize = true;
            this.rdThuThuCapNhat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdThuThuCapNhat.Location = new System.Drawing.Point(532, 123);
            this.rdThuThuCapNhat.Name = "rdThuThuCapNhat";
            this.rdThuThuCapNhat.Size = new System.Drawing.Size(67, 21);
            this.rdThuThuCapNhat.TabIndex = 55;
            this.rdThuThuCapNhat.TabStop = true;
            this.rdThuThuCapNhat.Text = "Thủ Thư";
            this.rdThuThuCapNhat.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(429, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(102, 17);
            this.label20.TabIndex = 54;
            this.label20.Text = "Loại Nhân Viên :";
            // 
            // btnCapNhatNhanVien
            // 
            this.btnCapNhatNhanVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(130)))), ((int)(((byte)(100)))));
            this.btnCapNhatNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapNhatNhanVien.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCapNhatNhanVien.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCapNhatNhanVien.Location = new System.Drawing.Point(294, 195);
            this.btnCapNhatNhanVien.Name = "btnCapNhatNhanVien";
            this.btnCapNhatNhanVien.Size = new System.Drawing.Size(117, 32);
            this.btnCapNhatNhanVien.TabIndex = 53;
            this.btnCapNhatNhanVien.Text = "Cập Nhật";
            this.btnCapNhatNhanVien.UseVisualStyleBackColor = false;
            this.btnCapNhatNhanVien.Click += new System.EventHandler(this.btnCapNhatNhanVien_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(430, 32);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 17);
            this.label19.TabIndex = 51;
            this.label19.Text = "Họ Tên :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(58, 82);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 17);
            this.label18.TabIndex = 49;
            this.label18.Text = "Tên Đăng Nhập :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(62, 145);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 17);
            this.label17.TabIndex = 47;
            this.label17.Text = "Ca Trực :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(58, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 17);
            this.label8.TabIndex = 45;
            this.label8.Text = "Mã Nhân Viên : ";
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.BackColor = System.Drawing.Color.Teal;
            this.btnXoaNV.FlatAppearance.BorderSize = 0;
            this.btnXoaNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaNV.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaNV.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXoaNV.Location = new System.Drawing.Point(460, 195);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(125, 32);
            this.btnXoaNV.TabIndex = 44;
            this.btnXoaNV.Text = "Xóa Nhân Viên";
            this.btnXoaNV.UseVisualStyleBackColor = false;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNhanVien.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvNhanVien.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvNhanVien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Location = new System.Drawing.Point(24, 251);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.Size = new System.Drawing.Size(847, 174);
            this.dgvNhanVien.TabIndex = 3;
            this.dgvNhanVien.Click += new System.EventHandler(this.dgvNhanVien_Click);
            // 
            // tbcDocGia
            // 
            this.tbcDocGia.Controls.Add(this.tabPage7);
            this.tbcDocGia.Controls.Add(this.tabThemdg);
            this.tbcDocGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbcDocGia.ImageList = this.imageList1;
            this.tbcDocGia.ItemSize = new System.Drawing.Size(110, 28);
            this.tbcDocGia.Location = new System.Drawing.Point(0, 1);
            this.tbcDocGia.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.tbcDocGia.Name = "tbcDocGia";
            this.tbcDocGia.SelectedIndex = 0;
            this.tbcDocGia.Size = new System.Drawing.Size(891, 459);
            this.tbcDocGia.TabIndex = 0;
            this.tbcDocGia.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tab_DrawItem);
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage7.Controls.Add(this.txtCTMSSV_DG);
            this.tabPage7.Controls.Add(this.lbCTMSSV_DG);
            this.tabPage7.Controls.Add(this.txtCTMSCB_DG);
            this.tabPage7.Controls.Add(this.lbCTMSCB_DG);
            this.tabPage7.Controls.Add(this.dtkCTNgaySinhDG);
            this.tabPage7.Controls.Add(this.rdCTKhach_DG);
            this.tabPage7.Controls.Add(this.rdCTCB_DG);
            this.tabPage7.Controls.Add(this.rdCTSV_DG);
            this.tabPage7.Controls.Add(this.lbCTLoaiDG);
            this.tabPage7.Controls.Add(this.txtCTPhoneDG);
            this.tabPage7.Controls.Add(this.lbCTPhoneDG);
            this.tabPage7.Controls.Add(this.txtCTCMNDDG);
            this.tabPage7.Controls.Add(this.txtCTMaDG);
            this.tabPage7.Controls.Add(this.txtCTEmailDG);
            this.tabPage7.Controls.Add(this.txtCTDiaChiDG);
            this.tabPage7.Controls.Add(this.txtCTTenDG);
            this.tabPage7.Controls.Add(this.lbCTCMNDDG);
            this.tabPage7.Controls.Add(this.lbCTEmailDG);
            this.tabPage7.Controls.Add(this.lbCTDiaChiDG);
            this.tabPage7.Controls.Add(this.lbCTNgaySinhDG);
            this.tabPage7.Controls.Add(this.lbCTMaDG);
            this.tabPage7.Controls.Add(this.lbCTTenDG);
            this.tabPage7.Controls.Add(this.cbxDinhDanh);
            this.tabPage7.Controls.Add(this.btnChinhSua);
            this.tabPage7.Controls.Add(this.btnHuy);
            this.tabPage7.Controls.Add(this.btnLuu);
            this.tabPage7.Controls.Add(this.btnXemAllDocGia);
            this.tabPage7.Controls.Add(this.btnLapPhieuCanhCao);
            this.tabPage7.Controls.Add(this.btnLapPhieuTra);
            this.tabPage7.Controls.Add(this.btnLapPhieMuon);
            this.tabPage7.Controls.Add(this.btnXoaDocGia);
            this.tabPage7.Controls.Add(this.btnXemChiTiet);
            this.tabPage7.Controls.Add(this.dgvDGSearch);
            this.tabPage7.Controls.Add(this.btnSearchDocGia);
            this.tabPage7.Controls.Add(this.lblHoTenSearch);
            this.tabPage7.Controls.Add(this.lblDinhDanhSearch);
            this.tabPage7.Controls.Add(this.lblMaDGSearch);
            this.tabPage7.Controls.Add(this.rdHoTenSearch);
            this.tabPage7.Controls.Add(this.rdMaDinhDanhSearch);
            this.tabPage7.Controls.Add(this.rdMaDGSearch);
            this.tabPage7.Controls.Add(this.txtSearchDG);
            this.tabPage7.Controls.Add(this.label30);
            this.tabPage7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage7.Location = new System.Drawing.Point(4, 32);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(883, 423);
            this.tabPage7.TabIndex = 4;
            this.tabPage7.Text = "Tìm Kiếm Độc Giả";
            // 
            // txtCTMSSV_DG
            // 
            this.txtCTMSSV_DG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTMSSV_DG.Location = new System.Drawing.Point(522, 288);
            this.txtCTMSSV_DG.Name = "txtCTMSSV_DG";
            this.txtCTMSSV_DG.Size = new System.Drawing.Size(248, 23);
            this.txtCTMSSV_DG.TabIndex = 79;
            // 
            // lbCTMSSV_DG
            // 
            this.lbCTMSSV_DG.AutoSize = true;
            this.lbCTMSSV_DG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTMSSV_DG.Location = new System.Drawing.Point(420, 294);
            this.lbCTMSSV_DG.Name = "lbCTMSSV_DG";
            this.lbCTMSSV_DG.Size = new System.Drawing.Size(40, 17);
            this.lbCTMSSV_DG.TabIndex = 78;
            this.lbCTMSSV_DG.Text = "MSSV";
            // 
            // txtCTMSCB_DG
            // 
            this.txtCTMSCB_DG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTMSCB_DG.Location = new System.Drawing.Point(522, 288);
            this.txtCTMSCB_DG.Name = "txtCTMSCB_DG";
            this.txtCTMSCB_DG.Size = new System.Drawing.Size(176, 23);
            this.txtCTMSCB_DG.TabIndex = 77;
            // 
            // lbCTMSCB_DG
            // 
            this.lbCTMSCB_DG.AutoSize = true;
            this.lbCTMSCB_DG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTMSCB_DG.Location = new System.Drawing.Point(421, 291);
            this.lbCTMSCB_DG.Name = "lbCTMSCB_DG";
            this.lbCTMSCB_DG.Size = new System.Drawing.Size(43, 17);
            this.lbCTMSCB_DG.TabIndex = 76;
            this.lbCTMSCB_DG.Text = "MSCB";
            // 
            // dtkCTNgaySinhDG
            // 
            this.dtkCTNgaySinhDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtkCTNgaySinhDG.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtkCTNgaySinhDG.Location = new System.Drawing.Point(152, 221);
            this.dtkCTNgaySinhDG.Name = "dtkCTNgaySinhDG";
            this.dtkCTNgaySinhDG.Size = new System.Drawing.Size(211, 26);
            this.dtkCTNgaySinhDG.TabIndex = 75;
            // 
            // rdCTKhach_DG
            // 
            this.rdCTKhach_DG.AutoSize = true;
            this.rdCTKhach_DG.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdCTKhach_DG.Location = new System.Drawing.Point(747, 249);
            this.rdCTKhach_DG.Name = "rdCTKhach_DG";
            this.rdCTKhach_DG.Size = new System.Drawing.Size(56, 21);
            this.rdCTKhach_DG.TabIndex = 71;
            this.rdCTKhach_DG.TabStop = true;
            this.rdCTKhach_DG.Text = "Khác";
            this.rdCTKhach_DG.UseVisualStyleBackColor = true;
            this.rdCTKhach_DG.CheckedChanged += new System.EventHandler(this.rdCTKhach_DG_CheckedChanged);
            // 
            // rdCTCB_DG
            // 
            this.rdCTCB_DG.AutoSize = true;
            this.rdCTCB_DG.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdCTCB_DG.Location = new System.Drawing.Point(607, 247);
            this.rdCTCB_DG.Name = "rdCTCB_DG";
            this.rdCTCB_DG.Size = new System.Drawing.Size(139, 21);
            this.rdCTCB_DG.TabIndex = 70;
            this.rdCTCB_DG.TabStop = true;
            this.rdCTCB_DG.Text = "Cán Bộ / Nhân Viên";
            this.rdCTCB_DG.UseVisualStyleBackColor = true;
            this.rdCTCB_DG.CheckedChanged += new System.EventHandler(this.rdCTCB_DG_CheckedChanged);
            // 
            // rdCTSV_DG
            // 
            this.rdCTSV_DG.AutoSize = true;
            this.rdCTSV_DG.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdCTSV_DG.Location = new System.Drawing.Point(521, 247);
            this.rdCTSV_DG.Name = "rdCTSV_DG";
            this.rdCTSV_DG.Size = new System.Drawing.Size(80, 21);
            this.rdCTSV_DG.TabIndex = 69;
            this.rdCTSV_DG.TabStop = true;
            this.rdCTSV_DG.Text = "Sinh Viên";
            this.rdCTSV_DG.UseVisualStyleBackColor = true;
            this.rdCTSV_DG.CheckedChanged += new System.EventHandler(this.rdCTSV_DG_CheckedChanged);
            // 
            // lbCTLoaiDG
            // 
            this.lbCTLoaiDG.AutoSize = true;
            this.lbCTLoaiDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTLoaiDG.Location = new System.Drawing.Point(420, 249);
            this.lbCTLoaiDG.Name = "lbCTLoaiDG";
            this.lbCTLoaiDG.Size = new System.Drawing.Size(90, 17);
            this.lbCTLoaiDG.TabIndex = 38;
            this.lbCTLoaiDG.Text = "Loại Độc Giả";
            // 
            // txtCTPhoneDG
            // 
            this.txtCTPhoneDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTPhoneDG.Location = new System.Drawing.Point(152, 271);
            this.txtCTPhoneDG.Name = "txtCTPhoneDG";
            this.txtCTPhoneDG.Size = new System.Drawing.Size(211, 23);
            this.txtCTPhoneDG.TabIndex = 37;
            // 
            // lbCTPhoneDG
            // 
            this.lbCTPhoneDG.AutoSize = true;
            this.lbCTPhoneDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTPhoneDG.Location = new System.Drawing.Point(45, 272);
            this.lbCTPhoneDG.Name = "lbCTPhoneDG";
            this.lbCTPhoneDG.Size = new System.Drawing.Size(57, 17);
            this.lbCTPhoneDG.TabIndex = 35;
            this.lbCTPhoneDG.Text = "Phone  ";
            // 
            // txtCTCMNDDG
            // 
            this.txtCTCMNDDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTCMNDDG.Location = new System.Drawing.Point(522, 214);
            this.txtCTCMNDDG.Name = "txtCTCMNDDG";
            this.txtCTCMNDDG.Size = new System.Drawing.Size(248, 23);
            this.txtCTCMNDDG.TabIndex = 34;
            // 
            // txtCTMaDG
            // 
            this.txtCTMaDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTMaDG.Location = new System.Drawing.Point(152, 134);
            this.txtCTMaDG.Name = "txtCTMaDG";
            this.txtCTMaDG.ReadOnly = true;
            this.txtCTMaDG.Size = new System.Drawing.Size(211, 23);
            this.txtCTMaDG.TabIndex = 33;
            // 
            // txtCTEmailDG
            // 
            this.txtCTEmailDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTEmailDG.Location = new System.Drawing.Point(521, 174);
            this.txtCTEmailDG.Name = "txtCTEmailDG";
            this.txtCTEmailDG.Size = new System.Drawing.Size(249, 23);
            this.txtCTEmailDG.TabIndex = 32;
            // 
            // txtCTDiaChiDG
            // 
            this.txtCTDiaChiDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTDiaChiDG.Location = new System.Drawing.Point(522, 131);
            this.txtCTDiaChiDG.Name = "txtCTDiaChiDG";
            this.txtCTDiaChiDG.Size = new System.Drawing.Size(248, 23);
            this.txtCTDiaChiDG.TabIndex = 31;
            // 
            // txtCTTenDG
            // 
            this.txtCTTenDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTTenDG.Location = new System.Drawing.Point(152, 179);
            this.txtCTTenDG.Name = "txtCTTenDG";
            this.txtCTTenDG.Size = new System.Drawing.Size(211, 23);
            this.txtCTTenDG.TabIndex = 29;
            // 
            // lbCTCMNDDG
            // 
            this.lbCTCMNDDG.AutoSize = true;
            this.lbCTCMNDDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTCMNDDG.Location = new System.Drawing.Point(420, 217);
            this.lbCTCMNDDG.Name = "lbCTCMNDDG";
            this.lbCTCMNDDG.Size = new System.Drawing.Size(50, 17);
            this.lbCTCMNDDG.TabIndex = 28;
            this.lbCTCMNDDG.Text = "CMND";
            // 
            // lbCTEmailDG
            // 
            this.lbCTEmailDG.AutoSize = true;
            this.lbCTEmailDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTEmailDG.Location = new System.Drawing.Point(420, 177);
            this.lbCTEmailDG.Name = "lbCTEmailDG";
            this.lbCTEmailDG.Size = new System.Drawing.Size(43, 17);
            this.lbCTEmailDG.TabIndex = 27;
            this.lbCTEmailDG.Text = "Email";
            // 
            // lbCTDiaChiDG
            // 
            this.lbCTDiaChiDG.AutoSize = true;
            this.lbCTDiaChiDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTDiaChiDG.Location = new System.Drawing.Point(420, 134);
            this.lbCTDiaChiDG.Name = "lbCTDiaChiDG";
            this.lbCTDiaChiDG.Size = new System.Drawing.Size(56, 17);
            this.lbCTDiaChiDG.TabIndex = 26;
            this.lbCTDiaChiDG.Text = "Địa Chỉ";
            // 
            // lbCTNgaySinhDG
            // 
            this.lbCTNgaySinhDG.AutoSize = true;
            this.lbCTNgaySinhDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTNgaySinhDG.Location = new System.Drawing.Point(47, 224);
            this.lbCTNgaySinhDG.Name = "lbCTNgaySinhDG";
            this.lbCTNgaySinhDG.Size = new System.Drawing.Size(71, 17);
            this.lbCTNgaySinhDG.TabIndex = 25;
            this.lbCTNgaySinhDG.Text = "Ngày Sinh";
            // 
            // lbCTMaDG
            // 
            this.lbCTMaDG.AutoSize = true;
            this.lbCTMaDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTMaDG.Location = new System.Drawing.Point(47, 137);
            this.lbCTMaDG.Name = "lbCTMaDG";
            this.lbCTMaDG.Size = new System.Drawing.Size(84, 17);
            this.lbCTMaDG.TabIndex = 24;
            this.lbCTMaDG.Text = "Mã Độc Giả";
            // 
            // lbCTTenDG
            // 
            this.lbCTTenDG.AutoSize = true;
            this.lbCTTenDG.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTTenDG.Location = new System.Drawing.Point(44, 180);
            this.lbCTTenDG.Name = "lbCTTenDG";
            this.lbCTTenDG.Size = new System.Drawing.Size(85, 17);
            this.lbCTTenDG.TabIndex = 23;
            this.lbCTTenDG.Text = "Tên Độc Giả";
            // 
            // cbxDinhDanh
            // 
            this.cbxDinhDanh.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDinhDanh.FormattingEnabled = true;
            this.cbxDinhDanh.Location = new System.Drawing.Point(343, 42);
            this.cbxDinhDanh.Name = "cbxDinhDanh";
            this.cbxDinhDanh.Size = new System.Drawing.Size(121, 28);
            this.cbxDinhDanh.TabIndex = 22;
            this.cbxDinhDanh.Text = "CMND";
            this.cbxDinhDanh.SelectedIndexChanged += new System.EventHandler(this.cbxDinhDanh_SelectedIndexChanged);
            // 
            // btnChinhSua
            // 
            this.btnChinhSua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(63)))), ((int)(((byte)(72)))));
            this.btnChinhSua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChinhSua.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChinhSua.ForeColor = System.Drawing.Color.White;
            this.btnChinhSua.Location = new System.Drawing.Point(120, 345);
            this.btnChinhSua.Name = "btnChinhSua";
            this.btnChinhSua.Size = new System.Drawing.Size(138, 43);
            this.btnChinhSua.TabIndex = 21;
            this.btnChinhSua.Text = "Chỉnh Sửa";
            this.btnChinhSua.UseVisualStyleBackColor = false;
            this.btnChinhSua.Click += new System.EventHandler(this.btnChinhSua_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(63)))), ((int)(((byte)(72)))));
            this.btnHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHuy.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuy.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHuy.Location = new System.Drawing.Point(553, 345);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(133, 44);
            this.btnHuy.TabIndex = 20;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = false;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(63)))), ((int)(((byte)(72)))));
            this.btnLuu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLuu.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuu.ForeColor = System.Drawing.Color.White;
            this.btnLuu.Location = new System.Drawing.Point(343, 347);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(138, 43);
            this.btnLuu.TabIndex = 19;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXemAllDocGia
            // 
            this.btnXemAllDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnXemAllDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemAllDocGia.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemAllDocGia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemAllDocGia.Location = new System.Drawing.Point(691, 68);
            this.btnXemAllDocGia.Name = "btnXemAllDocGia";
            this.btnXemAllDocGia.Size = new System.Drawing.Size(116, 33);
            this.btnXemAllDocGia.TabIndex = 18;
            this.btnXemAllDocGia.Text = "Xem Tất Cả";
            this.btnXemAllDocGia.UseVisualStyleBackColor = false;
            this.btnXemAllDocGia.Click += new System.EventHandler(this.btnXemAllDocGia_Click);
            // 
            // btnLapPhieuCanhCao
            // 
            this.btnLapPhieuCanhCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnLapPhieuCanhCao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLapPhieuCanhCao.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieuCanhCao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLapPhieuCanhCao.Location = new System.Drawing.Point(672, 346);
            this.btnLapPhieuCanhCao.Name = "btnLapPhieuCanhCao";
            this.btnLapPhieuCanhCao.Size = new System.Drawing.Size(176, 41);
            this.btnLapPhieuCanhCao.TabIndex = 17;
            this.btnLapPhieuCanhCao.Text = "Lập Phiếu Cảnh Cáo";
            this.btnLapPhieuCanhCao.UseVisualStyleBackColor = false;
            this.btnLapPhieuCanhCao.Click += new System.EventHandler(this.btnLapPhieuCanhCao_Click);
            // 
            // btnLapPhieuTra
            // 
            this.btnLapPhieuTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnLapPhieuTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLapPhieuTra.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieuTra.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLapPhieuTra.Location = new System.Drawing.Point(506, 346);
            this.btnLapPhieuTra.Name = "btnLapPhieuTra";
            this.btnLapPhieuTra.Size = new System.Drawing.Size(129, 41);
            this.btnLapPhieuTra.TabIndex = 16;
            this.btnLapPhieuTra.Text = "Lập Phiếu Trả";
            this.btnLapPhieuTra.UseVisualStyleBackColor = false;
            this.btnLapPhieuTra.Click += new System.EventHandler(this.btnLapPhieuTra_Click);
            // 
            // btnLapPhieMuon
            // 
            this.btnLapPhieMuon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnLapPhieMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLapPhieMuon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLapPhieMuon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLapPhieMuon.Location = new System.Drawing.Point(328, 346);
            this.btnLapPhieMuon.Name = "btnLapPhieMuon";
            this.btnLapPhieMuon.Size = new System.Drawing.Size(142, 41);
            this.btnLapPhieMuon.TabIndex = 15;
            this.btnLapPhieMuon.Text = "Lập Phiếu Mượn";
            this.btnLapPhieMuon.UseVisualStyleBackColor = false;
            this.btnLapPhieMuon.Click += new System.EventHandler(this.btnLapPhieMuon_Click);
            // 
            // btnXoaDocGia
            // 
            this.btnXoaDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnXoaDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaDocGia.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaDocGia.ForeColor = System.Drawing.Color.White;
            this.btnXoaDocGia.Location = new System.Drawing.Point(180, 346);
            this.btnXoaDocGia.Name = "btnXoaDocGia";
            this.btnXoaDocGia.Size = new System.Drawing.Size(117, 41);
            this.btnXoaDocGia.TabIndex = 14;
            this.btnXoaDocGia.Text = "Xóa";
            this.btnXoaDocGia.UseVisualStyleBackColor = false;
            this.btnXoaDocGia.Click += new System.EventHandler(this.btnXoaDocGia_Click);
            // 
            // btnXemChiTiet
            // 
            this.btnXemChiTiet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnXemChiTiet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXemChiTiet.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemChiTiet.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnXemChiTiet.Location = new System.Drawing.Point(30, 346);
            this.btnXemChiTiet.Name = "btnXemChiTiet";
            this.btnXemChiTiet.Size = new System.Drawing.Size(117, 41);
            this.btnXemChiTiet.TabIndex = 13;
            this.btnXemChiTiet.Text = "Xem Chi Tiết";
            this.btnXemChiTiet.UseVisualStyleBackColor = false;
            this.btnXemChiTiet.Click += new System.EventHandler(this.btnXemChiTiet_Click);
            // 
            // dgvDGSearch
            // 
            this.dgvDGSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDGSearch.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvDGSearch.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDGSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDGSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDGSearch.Location = new System.Drawing.Point(8, 123);
            this.dgvDGSearch.Name = "dgvDGSearch";
            this.dgvDGSearch.Size = new System.Drawing.Size(869, 199);
            this.dgvDGSearch.TabIndex = 9;
            // 
            // btnSearchDocGia
            // 
            this.btnSearchDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnSearchDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchDocGia.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchDocGia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearchDocGia.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchDocGia.Image")));
            this.btnSearchDocGia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearchDocGia.Location = new System.Drawing.Point(506, 69);
            this.btnSearchDocGia.Name = "btnSearchDocGia";
            this.btnSearchDocGia.Size = new System.Drawing.Size(123, 33);
            this.btnSearchDocGia.TabIndex = 8;
            this.btnSearchDocGia.Text = "Tìm Kiếm";
            this.btnSearchDocGia.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSearchDocGia.UseVisualStyleBackColor = false;
            this.btnSearchDocGia.Click += new System.EventHandler(this.btnSearchDocGia_Click);
            // 
            // lblHoTenSearch
            // 
            this.lblHoTenSearch.AutoSize = true;
            this.lblHoTenSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTenSearch.Location = new System.Drawing.Point(506, 17);
            this.lblHoTenSearch.Name = "lblHoTenSearch";
            this.lblHoTenSearch.Size = new System.Drawing.Size(64, 20);
            this.lblHoTenSearch.TabIndex = 7;
            this.lblHoTenSearch.Text = "Họ Tên :";
            // 
            // lblDinhDanhSearch
            // 
            this.lblDinhDanhSearch.AutoSize = true;
            this.lblDinhDanhSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinhDanhSearch.Location = new System.Drawing.Point(506, 19);
            this.lblDinhDanhSearch.Name = "lblDinhDanhSearch";
            this.lblDinhDanhSearch.Size = new System.Drawing.Size(163, 20);
            this.lblDinhDanhSearch.TabIndex = 6;
            this.lblDinhDanhSearch.Text = "CMND/MSSV/MSCB :";
            // 
            // lblMaDGSearch
            // 
            this.lblMaDGSearch.AutoSize = true;
            this.lblMaDGSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaDGSearch.Location = new System.Drawing.Point(506, 19);
            this.lblMaDGSearch.Name = "lblMaDGSearch";
            this.lblMaDGSearch.Size = new System.Drawing.Size(105, 20);
            this.lblMaDGSearch.TabIndex = 5;
            this.lblMaDGSearch.Text = "Mã Độc Giả :";
            // 
            // rdHoTenSearch
            // 
            this.rdHoTenSearch.AutoSize = true;
            this.rdHoTenSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdHoTenSearch.Location = new System.Drawing.Point(144, 82);
            this.rdHoTenSearch.Name = "rdHoTenSearch";
            this.rdHoTenSearch.Size = new System.Drawing.Size(74, 24);
            this.rdHoTenSearch.TabIndex = 4;
            this.rdHoTenSearch.TabStop = true;
            this.rdHoTenSearch.Text = "Họ Tên";
            this.rdHoTenSearch.UseVisualStyleBackColor = true;
            this.rdHoTenSearch.CheckedChanged += new System.EventHandler(this.rdHoTenSearch_CheckedChanged);
            // 
            // rdMaDinhDanhSearch
            // 
            this.rdMaDinhDanhSearch.AutoSize = true;
            this.rdMaDinhDanhSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaDinhDanhSearch.Location = new System.Drawing.Point(144, 46);
            this.rdMaDinhDanhSearch.Name = "rdMaDinhDanhSearch";
            this.rdMaDinhDanhSearch.Size = new System.Drawing.Size(173, 24);
            this.rdMaDinhDanhSearch.TabIndex = 3;
            this.rdMaDinhDanhSearch.TabStop = true;
            this.rdMaDinhDanhSearch.Text = "CMND/MSSV/MSCB";
            this.rdMaDinhDanhSearch.UseVisualStyleBackColor = true;
            this.rdMaDinhDanhSearch.CheckedChanged += new System.EventHandler(this.rdMaDinhDanhSearch_CheckedChanged);
            // 
            // rdMaDGSearch
            // 
            this.rdMaDGSearch.AutoSize = true;
            this.rdMaDGSearch.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdMaDGSearch.Location = new System.Drawing.Point(144, 10);
            this.rdMaDGSearch.Name = "rdMaDGSearch";
            this.rdMaDGSearch.Size = new System.Drawing.Size(115, 24);
            this.rdMaDGSearch.TabIndex = 2;
            this.rdMaDGSearch.TabStop = true;
            this.rdMaDGSearch.Text = "Mã Độc Giả";
            this.rdMaDGSearch.UseVisualStyleBackColor = true;
            this.rdMaDGSearch.CheckedChanged += new System.EventHandler(this.rdMaDGSearch_CheckedChanged);
            // 
            // txtSearchDG
            // 
            this.txtSearchDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchDG.Location = new System.Drawing.Point(617, 14);
            this.txtSearchDG.Name = "txtSearchDG";
            this.txtSearchDG.Size = new System.Drawing.Size(202, 26);
            this.txtSearchDG.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(16, 48);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(113, 20);
            this.label30.TabIndex = 0;
            this.label30.Text = "Tìm Kiếm Theo :";
            // 
            // tabThemdg
            // 
            this.tabThemdg.BackColor = System.Drawing.SystemColors.Control;
            this.tabThemdg.Controls.Add(this.groupBox3);
            this.tabThemdg.Location = new System.Drawing.Point(4, 32);
            this.tabThemdg.Name = "tabThemdg";
            this.tabThemdg.Padding = new System.Windows.Forms.Padding(3);
            this.tabThemdg.Size = new System.Drawing.Size(883, 423);
            this.tabThemdg.TabIndex = 1;
            this.tabThemdg.Text = "Thêm Đọc Giả";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnDangKyDocGia);
            this.groupBox3.Controls.Add(this.dtpk_ngaysinhDocGia);
            this.groupBox3.Controls.Add(this.txtMaDG);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.lblMSCBDangKy);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.lblMSSVDangKy);
            this.groupBox3.Controls.Add(this.rdKhac);
            this.groupBox3.Controls.Add(this.rdCanBo);
            this.groupBox3.Controls.Add(this.rdSinhVien);
            this.groupBox3.Controls.Add(this.txtCMNDDG);
            this.groupBox3.Controls.Add(this.txtMSCBDG);
            this.groupBox3.Controls.Add(this.txtMSSVDG);
            this.groupBox3.Controls.Add(this.txtEmailDG);
            this.groupBox3.Controls.Add(this.txtSDTDG);
            this.groupBox3.Controls.Add(this.txtDiaChiDG);
            this.groupBox3.Controls.Add(this.txtTenDG);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.lbUserName);
            this.groupBox3.Location = new System.Drawing.Point(27, 8);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox3.Size = new System.Drawing.Size(847, 399);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // btnDangKyDocGia
            // 
            this.btnDangKyDocGia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(43)))), ((int)(((byte)(72)))));
            this.btnDangKyDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDangKyDocGia.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDangKyDocGia.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDangKyDocGia.Location = new System.Drawing.Point(398, 350);
            this.btnDangKyDocGia.Name = "btnDangKyDocGia";
            this.btnDangKyDocGia.Size = new System.Drawing.Size(157, 35);
            this.btnDangKyDocGia.TabIndex = 71;
            this.btnDangKyDocGia.Text = "Đăng Ký";
            this.btnDangKyDocGia.UseVisualStyleBackColor = false;
            this.btnDangKyDocGia.Click += new System.EventHandler(this.btnDangKyDocGia_Click);
            // 
            // dtpk_ngaysinhDocGia
            // 
            this.dtpk_ngaysinhDocGia.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpk_ngaysinhDocGia.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpk_ngaysinhDocGia.Location = new System.Drawing.Point(196, 148);
            this.dtpk_ngaysinhDocGia.Name = "dtpk_ngaysinhDocGia";
            this.dtpk_ngaysinhDocGia.Size = new System.Drawing.Size(216, 26);
            this.dtpk_ngaysinhDocGia.TabIndex = 74;
            // 
            // txtMaDG
            // 
            this.txtMaDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDG.Location = new System.Drawing.Point(199, 28);
            this.txtMaDG.Name = "txtMaDG";
            this.txtMaDG.Size = new System.Drawing.Size(211, 26);
            this.txtMaDG.TabIndex = 73;
            // 
            // label29
            // 
            this.label29.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Image = ((System.Drawing.Image)(resources.GetObject("label29.Image")));
            this.label29.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label29.Location = new System.Drawing.Point(32, 9);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Padding = new System.Windows.Forms.Padding(2);
            this.label29.Size = new System.Drawing.Size(160, 54);
            this.label29.TabIndex = 72;
            this.label29.Text = "Mã Độc Giả :";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label29.UseCompatibleTextRendering = true;
            // 
            // label27
            // 
            this.label27.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Image = ((System.Drawing.Image)(resources.GetObject("label27.Image")));
            this.label27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label27.Location = new System.Drawing.Point(469, 87);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Padding = new System.Windows.Forms.Padding(2);
            this.label27.Size = new System.Drawing.Size(124, 54);
            this.label27.TabIndex = 71;
            this.label27.Text = "CMND :";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label27.UseCompatibleTextRendering = true;
            // 
            // lblMSCBDangKy
            // 
            this.lblMSCBDangKy.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblMSCBDangKy.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMSCBDangKy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblMSCBDangKy.Location = new System.Drawing.Point(482, 273);
            this.lblMSCBDangKy.Margin = new System.Windows.Forms.Padding(0);
            this.lblMSCBDangKy.Name = "lblMSCBDangKy";
            this.lblMSCBDangKy.Padding = new System.Windows.Forms.Padding(2);
            this.lblMSCBDangKy.Size = new System.Drawing.Size(60, 44);
            this.lblMSCBDangKy.TabIndex = 69;
            this.lblMSCBDangKy.Text = "MSCB";
            this.lblMSCBDangKy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMSCBDangKy.UseCompatibleTextRendering = true;
            // 
            // label12
            // 
            this.label12.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Image = ((System.Drawing.Image)(resources.GetObject("label12.Image")));
            this.label12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label12.Location = new System.Drawing.Point(24, 268);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(2);
            this.label12.Size = new System.Drawing.Size(126, 54);
            this.label12.TabIndex = 43;
            this.label12.Text = "SĐT :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label12.UseCompatibleTextRendering = true;
            // 
            // lblMSSVDangKy
            // 
            this.lblMSSVDangKy.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblMSSVDangKy.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMSSVDangKy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblMSSVDangKy.Location = new System.Drawing.Point(495, 274);
            this.lblMSSVDangKy.Margin = new System.Windows.Forms.Padding(0);
            this.lblMSSVDangKy.Name = "lblMSSVDangKy";
            this.lblMSSVDangKy.Padding = new System.Windows.Forms.Padding(2);
            this.lblMSSVDangKy.Size = new System.Drawing.Size(60, 44);
            this.lblMSSVDangKy.TabIndex = 68;
            this.lblMSSVDangKy.Text = "MSSV:";
            this.lblMSSVDangKy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMSSVDangKy.UseCompatibleTextRendering = true;
            // 
            // rdKhac
            // 
            this.rdKhac.AutoSize = true;
            this.rdKhac.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdKhac.Location = new System.Drawing.Point(649, 238);
            this.rdKhac.Name = "rdKhac";
            this.rdKhac.Size = new System.Drawing.Size(65, 24);
            this.rdKhac.TabIndex = 67;
            this.rdKhac.TabStop = true;
            this.rdKhac.Text = "Khác";
            this.rdKhac.UseVisualStyleBackColor = true;
            this.rdKhac.CheckedChanged += new System.EventHandler(this.rdKhac_CheckedChanged);
            // 
            // rdCanBo
            // 
            this.rdCanBo.AutoSize = true;
            this.rdCanBo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdCanBo.Location = new System.Drawing.Point(648, 201);
            this.rdCanBo.Name = "rdCanBo";
            this.rdCanBo.Size = new System.Drawing.Size(171, 24);
            this.rdCanBo.TabIndex = 66;
            this.rdCanBo.TabStop = true;
            this.rdCanBo.Text = "Cán Bộ / Nhân Viên";
            this.rdCanBo.UseVisualStyleBackColor = true;
            this.rdCanBo.CheckedChanged += new System.EventHandler(this.rdCanBo_CheckedChanged);
            // 
            // rdSinhVien
            // 
            this.rdSinhVien.AutoSize = true;
            this.rdSinhVien.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdSinhVien.Location = new System.Drawing.Point(649, 162);
            this.rdSinhVien.Name = "rdSinhVien";
            this.rdSinhVien.Size = new System.Drawing.Size(92, 24);
            this.rdSinhVien.TabIndex = 65;
            this.rdSinhVien.TabStop = true;
            this.rdSinhVien.Text = "Sinh Viên";
            this.rdSinhVien.UseVisualStyleBackColor = true;
            this.rdSinhVien.CheckedChanged += new System.EventHandler(this.rdSinhVien_CheckedChanged);
            // 
            // txtCMNDDG
            // 
            this.txtCMNDDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCMNDDG.Location = new System.Drawing.Point(601, 105);
            this.txtCMNDDG.Name = "txtCMNDDG";
            this.txtCMNDDG.Size = new System.Drawing.Size(211, 26);
            this.txtCMNDDG.TabIndex = 64;
            // 
            // txtMSCBDG
            // 
            this.txtMSCBDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSCBDG.Location = new System.Drawing.Point(571, 282);
            this.txtMSCBDG.Name = "txtMSCBDG";
            this.txtMSCBDG.Size = new System.Drawing.Size(211, 26);
            this.txtMSCBDG.TabIndex = 63;
            // 
            // txtMSSVDG
            // 
            this.txtMSSVDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMSSVDG.Location = new System.Drawing.Point(571, 282);
            this.txtMSSVDG.Name = "txtMSSVDG";
            this.txtMSSVDG.Size = new System.Drawing.Size(211, 26);
            this.txtMSSVDG.TabIndex = 62;
            // 
            // txtEmailDG
            // 
            this.txtEmailDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailDG.Location = new System.Drawing.Point(601, 28);
            this.txtEmailDG.Name = "txtEmailDG";
            this.txtEmailDG.Size = new System.Drawing.Size(211, 26);
            this.txtEmailDG.TabIndex = 61;
            // 
            // txtSDTDG
            // 
            this.txtSDTDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDTDG.Location = new System.Drawing.Point(196, 292);
            this.txtSDTDG.Name = "txtSDTDG";
            this.txtSDTDG.Size = new System.Drawing.Size(216, 26);
            this.txtSDTDG.TabIndex = 60;
            // 
            // txtDiaChiDG
            // 
            this.txtDiaChiDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChiDG.Location = new System.Drawing.Point(196, 223);
            this.txtDiaChiDG.Name = "txtDiaChiDG";
            this.txtDiaChiDG.Size = new System.Drawing.Size(216, 26);
            this.txtDiaChiDG.TabIndex = 59;
            // 
            // txtTenDG
            // 
            this.txtTenDG.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDG.Location = new System.Drawing.Point(199, 83);
            this.txtTenDG.Name = "txtTenDG";
            this.txtTenDG.Size = new System.Drawing.Size(211, 26);
            this.txtTenDG.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(469, 179);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(2);
            this.label6.Size = new System.Drawing.Size(173, 54);
            this.label6.TabIndex = 52;
            this.label6.Text = "Loại Độc Gải :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label6.UseCompatibleTextRendering = true;
            // 
            // label13
            // 
            this.label13.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(24, 136);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Padding = new System.Windows.Forms.Padding(2);
            this.label13.Size = new System.Drawing.Size(147, 54);
            this.label13.TabIndex = 44;
            this.label13.Text = "Ngày Sinh :\r\n";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label13.UseCompatibleTextRendering = true;
            // 
            // label11
            // 
            this.label11.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Image = ((System.Drawing.Image)(resources.GetObject("label11.Image")));
            this.label11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label11.Location = new System.Drawing.Point(24, 205);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(2);
            this.label11.Size = new System.Drawing.Size(137, 54);
            this.label11.TabIndex = 42;
            this.label11.Text = "Địa Chỉ :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label11.UseCompatibleTextRendering = true;
            // 
            // label10
            // 
            this.label10.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Image = ((System.Drawing.Image)(resources.GetObject("label10.Image")));
            this.label10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label10.Location = new System.Drawing.Point(469, 9);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(2);
            this.label10.Size = new System.Drawing.Size(124, 54);
            this.label10.TabIndex = 41;
            this.label10.Text = "Email :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label10.UseCompatibleTextRendering = true;
            // 
            // lbUserName
            // 
            this.lbUserName.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbUserName.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUserName.Image = ((System.Drawing.Image)(resources.GetObject("lbUserName.Image")));
            this.lbUserName.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbUserName.Location = new System.Drawing.Point(24, 66);
            this.lbUserName.Margin = new System.Windows.Forms.Padding(0);
            this.lbUserName.Name = "lbUserName";
            this.lbUserName.Padding = new System.Windows.Forms.Padding(2);
            this.lbUserName.Size = new System.Drawing.Size(147, 54);
            this.lbUserName.TabIndex = 40;
            this.lbUserName.Text = "Tên Đọc Giả :";
            this.lbUserName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbUserName.UseCompatibleTextRendering = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "icons8-user (1).png");
            this.imageList1.Images.SetKeyName(1, "icons8-add-user-male (2).png");
            this.imageList1.Images.SetKeyName(2, "icons8-user-location (1).png");
            this.imageList1.Images.SetKeyName(3, "icons8-delete-shield (1).png");
            // 
            // panelDocGia
            // 
            this.panelDocGia.Controls.Add(this.tbcDocGia);
            this.panelDocGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelDocGia.Location = new System.Drawing.Point(903, 49);
            this.panelDocGia.Name = "panelDocGia";
            this.panelDocGia.Size = new System.Drawing.Size(911, 470);
            this.panelDocGia.TabIndex = 3;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(44, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(73, 57);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "icons8-book.png");
            this.imageList2.Images.SetKeyName(1, "icons8-bookmark-ribbon.png");
            this.imageList2.Images.SetKeyName(2, "icons8-books.png");
            this.imageList2.Images.SetKeyName(3, "icons8-add-book-48 (1).png");
            this.imageList2.Images.SetKeyName(4, "icons8-read-filled-48.png");
            // 
            // imageList3
            // 
            this.imageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList3.ImageStream")));
            this.imageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList3.Images.SetKeyName(0, "icons8-male-user.png");
            this.imageList3.Images.SetKeyName(1, "icons8-change-user.png");
            this.imageList3.Images.SetKeyName(2, "icons8-trash-can.png");
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogout.Image = ((System.Drawing.Image)(resources.GetObject("btnLogout.Image")));
            this.btnLogout.Location = new System.Drawing.Point(1071, 34);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(57, 51);
            this.btnLogout.TabIndex = 16;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // imageList4
            // 
            this.imageList4.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList4.ImageStream")));
            this.imageList4.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList4.Images.SetKeyName(0, "icons8-borrow-book-filled-48 (1).png");
            this.imageList4.Images.SetKeyName(1, "icons8-bill-filled-48.png");
            this.imageList4.Images.SetKeyName(2, "icons8-high-priority-filled-48.png");
            this.imageList4.Images.SetKeyName(3, "icons8-locked-door-filled-48.png");
            // 
            // imageList5
            // 
            this.imageList5.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList5.ImageStream")));
            this.imageList5.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList5.Images.SetKeyName(0, "icons8-borrow-book-filled-48 (2).png");
            this.imageList5.Images.SetKeyName(1, "icons8-borrow-book-filled-48 (3).png");
            this.imageList5.Images.SetKeyName(2, "icons8-bill-filled-48 (1).png");
            this.imageList5.Images.SetKeyName(3, "icons8-bill-filled-48 (2).png");
            // 
            // imageList6
            // 
            this.imageList6.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList6.ImageStream")));
            this.imageList6.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList6.Images.SetKeyName(0, "icons8-change-user.png");
            this.imageList6.Images.SetKeyName(1, "icons8-user-location (1).png");
            // 
            // cbxCTTLDB
            // 
            this.cbxCTTLDB.AutoSize = true;
            this.cbxCTTLDB.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxCTTLDB.Location = new System.Drawing.Point(149, 258);
            this.cbxCTTLDB.Name = "cbxCTTLDB";
            this.cbxCTTLDB.Size = new System.Drawing.Size(149, 21);
            this.cbxCTTLDB.TabIndex = 85;
            this.cbxCTTLDB.Text = "Là Tài Liệu Đặc Biệt";
            this.cbxCTTLDB.UseVisualStyleBackColor = true;
            // 
            // lbCTSoLuongTL
            // 
            this.lbCTSoLuongTL.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbCTSoLuongTL.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTSoLuongTL.ForeColor = System.Drawing.Color.Black;
            this.lbCTSoLuongTL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbCTSoLuongTL.Location = new System.Drawing.Point(448, 187);
            this.lbCTSoLuongTL.Margin = new System.Windows.Forms.Padding(0);
            this.lbCTSoLuongTL.Name = "lbCTSoLuongTL";
            this.lbCTSoLuongTL.Padding = new System.Windows.Forms.Padding(2);
            this.lbCTSoLuongTL.Size = new System.Drawing.Size(82, 54);
            this.lbCTSoLuongTL.TabIndex = 84;
            this.lbCTSoLuongTL.Text = "Số Lượng :";
            this.lbCTSoLuongTL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbCTSoLuongTL.UseCompatibleTextRendering = true;
            // 
            // txtCTMaTaiLieu
            // 
            this.txtCTMaTaiLieu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTMaTaiLieu.Location = new System.Drawing.Point(149, 149);
            this.txtCTMaTaiLieu.Name = "txtCTMaTaiLieu";
            this.txtCTMaTaiLieu.Size = new System.Drawing.Size(256, 23);
            this.txtCTMaTaiLieu.TabIndex = 83;
            // 
            // lbCTMaTL
            // 
            this.lbCTMaTL.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbCTMaTL.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTMaTL.ForeColor = System.Drawing.Color.Black;
            this.lbCTMaTL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbCTMaTL.Location = new System.Drawing.Point(38, 130);
            this.lbCTMaTL.Margin = new System.Windows.Forms.Padding(0);
            this.lbCTMaTL.Name = "lbCTMaTL";
            this.lbCTMaTL.Padding = new System.Windows.Forms.Padding(2);
            this.lbCTMaTL.Size = new System.Drawing.Size(104, 54);
            this.lbCTMaTL.TabIndex = 82;
            this.lbCTMaTL.Text = "Mã Tài Liệu :";
            this.lbCTMaTL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbCTMaTL.UseCompatibleTextRendering = true;
            // 
            // txtCTSoLuongTL
            // 
            this.txtCTSoLuongTL.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTSoLuongTL.Location = new System.Drawing.Point(565, 204);
            this.txtCTSoLuongTL.Name = "txtCTSoLuongTL";
            this.txtCTSoLuongTL.Size = new System.Drawing.Size(209, 23);
            this.txtCTSoLuongTL.TabIndex = 81;
            // 
            // txtCTTenTaiLieu
            // 
            this.txtCTTenTaiLieu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCTTenTaiLieu.Location = new System.Drawing.Point(149, 204);
            this.txtCTTenTaiLieu.Name = "txtCTTenTaiLieu";
            this.txtCTTenTaiLieu.Size = new System.Drawing.Size(256, 23);
            this.txtCTTenTaiLieu.TabIndex = 79;
            // 
            // lbCTLoaiTaiLieu
            // 
            this.lbCTLoaiTaiLieu.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbCTLoaiTaiLieu.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTLoaiTaiLieu.ForeColor = System.Drawing.Color.Black;
            this.lbCTLoaiTaiLieu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbCTLoaiTaiLieu.Location = new System.Drawing.Point(420, 136);
            this.lbCTLoaiTaiLieu.Margin = new System.Windows.Forms.Padding(0);
            this.lbCTLoaiTaiLieu.Name = "lbCTLoaiTaiLieu";
            this.lbCTLoaiTaiLieu.Padding = new System.Windows.Forms.Padding(2);
            this.lbCTLoaiTaiLieu.Size = new System.Drawing.Size(130, 54);
            this.lbCTLoaiTaiLieu.TabIndex = 78;
            this.lbCTLoaiTaiLieu.Text = "Loại Tài Liệu :";
            this.lbCTLoaiTaiLieu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbCTLoaiTaiLieu.UseCompatibleTextRendering = true;
            // 
            // lbCTTenTaiLieu
            // 
            this.lbCTTenTaiLieu.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lbCTTenTaiLieu.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCTTenTaiLieu.ForeColor = System.Drawing.Color.Black;
            this.lbCTTenTaiLieu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbCTTenTaiLieu.Location = new System.Drawing.Point(38, 185);
            this.lbCTTenTaiLieu.Margin = new System.Windows.Forms.Padding(0);
            this.lbCTTenTaiLieu.Name = "lbCTTenTaiLieu";
            this.lbCTTenTaiLieu.Padding = new System.Windows.Forms.Padding(2);
            this.lbCTTenTaiLieu.Size = new System.Drawing.Size(104, 54);
            this.lbCTTenTaiLieu.TabIndex = 77;
            this.lbCTTenTaiLieu.Text = "Tên Tài Liệu :";
            this.lbCTTenTaiLieu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbCTTenTaiLieu.UseCompatibleTextRendering = true;
            // 
            // cbbCTLoaiTL
            // 
            this.cbbCTLoaiTL.Font = new System.Drawing.Font("VNF-Gotham", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.cbbCTLoaiTL.FormattingEnabled = true;
            this.cbbCTLoaiTL.Location = new System.Drawing.Point(565, 148);
            this.cbbCTLoaiTL.Name = "cbbCTLoaiTL";
            this.cbbCTLoaiTL.Size = new System.Drawing.Size(209, 23);
            this.cbbCTLoaiTL.TabIndex = 86;
            this.cbbCTLoaiTL.Text = "SÁCH";
            // 
            // GUI_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 570);
            this.ControlBox = false;
            this.Controls.Add(this.panelQuanTriAdmin);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.pnThongKe);
            this.Controls.Add(this.panelReport);
            this.Controls.Add(this.panelDocGia);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panelQLSach);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.ptB_AnhNhanVien);
            this.Controls.Add(this.lbTittle);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GUI_Home";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptB_AnhNhanVien)).EndInit();
            this.panelQLSach.ResumeLayout(false);
            this.tbcQuanLiSach.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchTaiLieu)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYeuCauTaiLieu)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.panelReport.ResumeLayout(false);
            this.pnThongKe.ResumeLayout(false);
            this.tbcQuanLiPhieu.ResumeLayout(false);
            this.tabPhieuMuon.ResumeLayout(false);
            this.tbcPhieuMuon.ResumeLayout(false);
            this.tabTimKiemPhieuMuon.ResumeLayout(false);
            this.tabTimKiemPhieuMuon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuMuon)).EndInit();
            this.tabThemPhieuMuon.ResumeLayout(false);
            this.tabThemPhieuMuon.PerformLayout();
            this.tabPhieuTra.ResumeLayout(false);
            this.tabPhieuTra.PerformLayout();
            this.tbcPhieuTra.ResumeLayout(false);
            this.tabPage_TimkiemPhieuTra.ResumeLayout(false);
            this.tabPage_TimkiemPhieuTra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuTra)).EndInit();
            this.tabpage_ThemPhieuTra.ResumeLayout(false);
            this.tabpage_ThemPhieuTra.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPhieuPhat.ResumeLayout(false);
            this.tabPhieuPhat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuPhat)).EndInit();
            this.tabPhieuNhacNho.ResumeLayout(false);
            this.tabPhieuNhacNho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNhacNho)).EndInit();
            this.panelQuanTriAdmin.ResumeLayout(false);
            this.tbcQuanTriAdmin.ResumeLayout(false);
            this.tbcAdmin_DocGia.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoaiDocGia)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tbcAdmin_NhanVien.ResumeLayout(false);
            this.tbcAdmin_NhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.tbcDocGia.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDGSearch)).EndInit();
            this.tabThemdg.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panelDocGia.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbTittle;
        private System.Windows.Forms.PictureBox ptB_AnhNhanVien;
        private System.Windows.Forms.Label userName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelQLSach;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnQuanLyPhieu;
        private System.Windows.Forms.Button btnPanelSach;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelDocGia;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.ImageList imageList3;
        private System.Windows.Forms.Button btnDocGia;
        private System.Windows.Forms.TabControl tbcDocGia;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXemAllDocGia;
        private System.Windows.Forms.Button btnLapPhieuCanhCao;
        private System.Windows.Forms.Button btnLapPhieuTra;
        private System.Windows.Forms.Button btnLapPhieMuon;
        private System.Windows.Forms.Button btnXoaDocGia;
        private System.Windows.Forms.Button btnXemChiTiet;
        private System.Windows.Forms.DataGridView dgvDGSearch;
        private System.Windows.Forms.Button btnSearchDocGia;
        private System.Windows.Forms.Label lblHoTenSearch;
        private System.Windows.Forms.Label lblDinhDanhSearch;
        private System.Windows.Forms.Label lblMaDGSearch;
        private System.Windows.Forms.RadioButton rdHoTenSearch;
        private System.Windows.Forms.RadioButton rdMaDinhDanhSearch;
        private System.Windows.Forms.RadioButton rdMaDGSearch;
        private System.Windows.Forms.TextBox txtSearchDG;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabThemdg;
        private System.Windows.Forms.Button btnDangKyDocGia;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtMaDG;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblMSCBDangKy;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblMSSVDangKy;
        private System.Windows.Forms.RadioButton rdKhac;
        private System.Windows.Forms.RadioButton rdCanBo;
        private System.Windows.Forms.RadioButton rdSinhVien;
        private System.Windows.Forms.TextBox txtCMNDDG;
        private System.Windows.Forms.TextBox txtMSCBDG;
        private System.Windows.Forms.TextBox txtMSSVDG;
        private System.Windows.Forms.TextBox txtEmailDG;
        private System.Windows.Forms.TextBox txtSDTDG;
        private System.Windows.Forms.TextBox txtDiaChiDG;
        private System.Windows.Forms.TextBox txtTenDG;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbUserName;
        private System.Windows.Forms.Button btnChinhSua;
        private System.Windows.Forms.ComboBox cbxDinhDanh;
        private System.Windows.Forms.TabControl tbcQuanLiSach;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnYeuCauTL;
        private System.Windows.Forms.Button btnXemTheoLoai;
        private System.Windows.Forms.ComboBox cbxLoaiTaiLieu;
        private System.Windows.Forms.Button btnChinhSuaTL;
        private System.Windows.Forms.Button btnHuyTL;
        private System.Windows.Forms.Button btnLuuTL;
        private System.Windows.Forms.Button btnXemAllTaiLieu;
        private System.Windows.Forms.Button btnLapPhieuMuonTL;
        private System.Windows.Forms.Button btnXoaTL;
        private System.Windows.Forms.Button btnXemChiTietTL;
        private System.Windows.Forms.DataGridView dgvSearchTaiLieu;
        private System.Windows.Forms.Button btnSearchTaiLieu;
        private System.Windows.Forms.Label lblTenTaiLieu;
        private System.Windows.Forms.Label lblMaTaiLieu;
        private System.Windows.Forms.RadioButton rdTimTLNangCao;
        private System.Windows.Forms.RadioButton rdTimTLCoBan;
        private System.Windows.Forms.TextBox txtSearchTaiLieu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnThemTaiLieu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMaTL;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSoLuongTL;
        private System.Windows.Forms.TextBox txtLoaiTL;
        private System.Windows.Forms.TextBox txtTenTL;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel pnThongKe;
        private System.Windows.Forms.TabControl tbcQuanLiPhieu;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panelReport;
        private System.Windows.Forms.Button btnReport_SoSachMuonNhieuNhat;
        private System.Windows.Forms.Button btnReport_TongSoSach;
        private System.Windows.Forms.TabPage tabPhieuMuon;
        private System.Windows.Forms.TabControl tbcPhieuMuon;
        private System.Windows.Forms.TabPage tabThemPhieuMuon;
        private System.Windows.Forms.Button btnThem_PhieuMuon;
        private System.Windows.Forms.TabPage tabTimKiemPhieuMuon;
        private System.Windows.Forms.Button btnHuy_PhieuMuon;
        private System.Windows.Forms.Button btnXemTatcaPhieuMuon;
        private System.Windows.Forms.Button btnXoaPhieuMuon;
        private System.Windows.Forms.Button btnXemChiTiet_PhieuMuon;
        private System.Windows.Forms.DataGridView dgvPhieuMuon;
        private System.Windows.Forms.Button btnTimKiemPhieuMuon;
        private System.Windows.Forms.RadioButton rdMaPhieuMuon;
        private System.Windows.Forms.RadioButton rdMaDG_PhieuMuon;
        private System.Windows.Forms.TextBox txtSearchPM;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPhieuTra;
        private System.Windows.Forms.TabControl tbcPhieuTra;
        private System.Windows.Forms.TabPage tabpage_ThemPhieuTra;
        private System.Windows.Forms.Button btnThemPhieuTra;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TabPage tabPage_TimkiemPhieuTra;
        private System.Windows.Forms.Button btnChinhSua_PhieuTra;
        private System.Windows.Forms.Button btnHuy_PhieuTra;
        private System.Windows.Forms.Button btnLuuPhieuTra;
        private System.Windows.Forms.Button btnXemTatCaPhieuTra;
        private System.Windows.Forms.Button btnXoaPhieuTra;
        private System.Windows.Forms.Button btnXemChiTietPhieuTra;
        private System.Windows.Forms.DataGridView dgvPhieuTra;
        private System.Windows.Forms.Button btnTimKiemPhieuTra;
        private System.Windows.Forms.RadioButton rdMaPhieuTra;
        private System.Windows.Forms.RadioButton rdMaDG_PhieuTra;
        private System.Windows.Forms.TextBox txtSearchPT;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button btnXoaPT;
        private System.Windows.Forms.Button btnXemChiTietPT;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnTimKiemPT;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TabPage tabPhieuPhat;
        private System.Windows.Forms.Button btnXemTatCaPhieuPhat;
        private System.Windows.Forms.Button btnXoaPP;
        private System.Windows.Forms.DataGridView dgvPhieuPhat;
        private System.Windows.Forms.Button btnSearchPP;
        private System.Windows.Forms.RadioButton rdMaPM_PP;
        private System.Windows.Forms.RadioButton rdMDG_PP;
        private System.Windows.Forms.TextBox txtSearchMaPP;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TabPage tabPhieuNhacNho;
        private System.Windows.Forms.Button btnXemTatCaPhieuNhacNho;
        private System.Windows.Forms.Button btnXoaPhieuNN;
        private System.Windows.Forms.DataGridView dgvPhieuNhacNho;
        private System.Windows.Forms.Button btnThemPhieuNhacNho;
        private System.Windows.Forms.DateTimePicker dtpk_ngaysinhDocGia;
        private System.Windows.Forms.RadioButton rdMaPhieuMuon_PhieuTraTK;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnYeuCauTaiLieuMoi;
        private System.Windows.Forms.Button btnXoaYeuCauTaiLieuMoi;
        private System.Windows.Forms.DataGridView dgvYeuCauTaiLieu;
        private System.Windows.Forms.TextBox txtYeuCauTaiLieuMoi;
        private System.Windows.Forms.Label lbTenTaiLieuYeuCauMoi;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cbxMaTLPM;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cbxMaDGPM;
        private System.Windows.Forms.ListBox lbListSachMuon;
        private System.Windows.Forms.Button btnXoaMTLTrongList;
        private System.Windows.Forms.Button btnAddMTLVaoList;
        private System.Windows.Forms.ListBox lbListSachMuonHide;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox lbDanhSachSachTra;
        private System.Windows.Forms.ComboBox cbxMaPMCuaPT;
        private System.Windows.Forms.ComboBox cbxSachPT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnXoaSachTra;
        private System.Windows.Forms.Button btnAddSachTra;
        private System.Windows.Forms.ListBox lbDanhSachSachTraHide;
        private System.Windows.Forms.Label lbMaTLPhieuMuon;
        private System.Windows.Forms.Label lbMaTaiLieuPhieuMuon;
        private System.Windows.Forms.Label lbMaDocGiaPhieuMuon;
        private System.Windows.Forms.Label lbMaDocGia;
        private System.Windows.Forms.Button btnBaoCaoThongKe;
        private System.Windows.Forms.Button btnSaveReport;
        private System.Windows.Forms.Button btnReport_TongSoDocGia;
        private System.Windows.Forms.ComboBox cbxMaPMcuaPP;
        private System.Windows.Forms.Button btn_LapPhieuPhat;
        private System.Windows.Forms.Label lbMaPM_PP;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnQuanTriAdmin;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer cryReportViewer;
        private System.Windows.Forms.ComboBox cbxmaDocGiaNN;
        private System.Windows.Forms.Button btnChinhSuaPNN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMaPNN;
        private System.Windows.Forms.Button btnSearchPNN;
        private System.Windows.Forms.RadioButton rdMPP_PP;
        private System.Windows.Forms.Panel panelQuanTriAdmin;
        private System.Windows.Forms.TabControl tbcQuanTriAdmin;
        private System.Windows.Forms.TabPage tbcAdmin_DocGia;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtADTLDB;
        private System.Windows.Forms.TextBox txtADTDG;
        private System.Windows.Forms.Button btnADTLDG;
        private System.Windows.Forms.Button btnADCNLDG;
        private System.Windows.Forms.TextBox txtADPTN;
        private System.Windows.Forms.TextBox txtADSSM;
        private System.Windows.Forms.TextBox txtADSoNM;
        private System.Windows.Forms.TextBox txtADMaLoai;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabPage tbcAdmin_NhanVien;
        private System.Windows.Forms.TextBox txtMatKhauNVCapNhat;
        private System.Windows.Forms.TextBox txtHoTenNVCapNhat;
        private System.Windows.Forms.TextBox txtTenDangNhapNVCapNhat;
        private System.Windows.Forms.TextBox txtCaTrucNVCapNhat;
        private System.Windows.Forms.TextBox txtSearchPhieuMuon;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton rdAdminCapNhat;
        private System.Windows.Forms.RadioButton rdThuThuCapNhat;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnCapNhatNhanVien;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.ImageList imageList4;
        private System.Windows.Forms.ImageList imageList5;
        private System.Windows.Forms.ImageList imageList6;
        private System.Windows.Forms.DataGridView dgvLoaiDocGia;
        private System.Windows.Forms.Button btnChinhSua_CTPM;
        private System.Windows.Forms.Button btnLuuCTPM;
        private System.Windows.Forms.TextBox txtCapNhatCTPM;
        private System.Windows.Forms.CheckBox ckbTLDB;
        private System.Windows.Forms.Label lbCTLoaiDG;
        private System.Windows.Forms.TextBox txtCTPhoneDG;
        private System.Windows.Forms.Label lbCTPhoneDG;
        private System.Windows.Forms.TextBox txtCTCMNDDG;
        private System.Windows.Forms.TextBox txtCTMaDG;
        private System.Windows.Forms.TextBox txtCTEmailDG;
        private System.Windows.Forms.TextBox txtCTDiaChiDG;
        private System.Windows.Forms.TextBox txtCTTenDG;
        private System.Windows.Forms.Label lbCTCMNDDG;
        private System.Windows.Forms.Label lbCTEmailDG;
        private System.Windows.Forms.Label lbCTDiaChiDG;
        private System.Windows.Forms.Label lbCTNgaySinhDG;
        private System.Windows.Forms.Label lbCTMaDG;
        private System.Windows.Forms.Label lbCTTenDG;
        private System.Windows.Forms.TextBox txtCTMSSV_DG;
        private System.Windows.Forms.Label lbCTMSSV_DG;
        private System.Windows.Forms.TextBox txtCTMSCB_DG;
        private System.Windows.Forms.Label lbCTMSCB_DG;
        private System.Windows.Forms.DateTimePicker dtkCTNgaySinhDG;
        private System.Windows.Forms.RadioButton rdCTKhach_DG;
        private System.Windows.Forms.RadioButton rdCTCB_DG;
        private System.Windows.Forms.RadioButton rdCTSV_DG;
        private System.Windows.Forms.CheckBox cbxCTTLDB;
        private System.Windows.Forms.Label lbCTSoLuongTL;
        private System.Windows.Forms.TextBox txtCTMaTaiLieu;
        private System.Windows.Forms.Label lbCTMaTL;
        private System.Windows.Forms.TextBox txtCTSoLuongTL;
        private System.Windows.Forms.TextBox txtCTTenTaiLieu;
        private System.Windows.Forms.Label lbCTLoaiTaiLieu;
        private System.Windows.Forms.Label lbCTTenTaiLieu;
        private System.Windows.Forms.ComboBox cbbCTLoaiTL;
    }
}